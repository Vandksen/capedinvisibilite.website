"""Mise à jour régulière : une version publiée sert à pseudonymiser pendant 30 jours.

Les correctifs du moteur touchent à la protection des données : au-delà de `VALIDITY_DAYS` jours
après sa publication, une version ne pseudonymise plus et invite à installer la dernière. Les
tables déjà créées restent valables et le rétablissement fonctionne toujours, pour que personne
ne perde l'accès à ses vraies valeurs.

La date de publication est inscrite dans le paquet à sa construction
(`packaging/construire_archives.py`). Dans le dépôt, elle est absente : aucune échéance. Tout se
décide sur le poste, avec sa date : aucun appel réseau.
"""

from __future__ import annotations

from datetime import date, timedelta

import invisibility_cloak
from invisibility_cloak.errors import UpdateRequiredError

# Durée pendant laquelle une version publiée pseudonymise
VALIDITY_DAYS = 30
EXPIRED_MESSAGE = (
    "Mise à jour régulière : cette version a plus de 30 jours. Installez la dernière version "
    "pour pseudonymiser de nouveaux fichiers. Vos tables restent valables et « Rétablir » "
    "fonctionne toujours."
)
CLOCK_MESSAGE = (
    "La date de ce poste est antérieure à la publication de cette version : vérifiez l'horloge "
    "du poste, ou installez la dernière version."
)


def publication_date() -> date | None:
    """Date de publication inscrite dans le paquet ; None dans le dépôt (pas d'échéance)."""
    value = invisibility_cloak.PUBLICATION_DATE
    return date.fromisoformat(value) if value else None


def days_left(today: date | None = None) -> int | None:
    """Jours restants avant la mise à jour (0 ou moins : à faire) ; None sans échéance."""
    published = publication_date()
    if published is None:
        return None
    return (published + timedelta(days=VALIDITY_DAYS) - (today or date.today())).days


def update_message(today: date | None = None) -> str | None:
    """Message si cette version ne pseudonymise plus, None sinon."""
    published = publication_date()
    if published is None:
        return None
    today = today or date.today()
    if today < published:
        return CLOCK_MESSAGE
    left = days_left(today)
    return EXPIRED_MESSAGE if left is not None and left <= 0 else None


def check_current() -> None:
    """Refuse de pseudonymiser avec une version à mettre à jour."""
    message = update_message()
    if message:
        raise UpdateRequiredError(message)
