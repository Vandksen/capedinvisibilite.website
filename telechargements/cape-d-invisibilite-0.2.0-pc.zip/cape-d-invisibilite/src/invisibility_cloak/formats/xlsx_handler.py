"""Classeurs Excel (.xlsx) via openpyxl.

Sont transformés : cellules texte, textes entre guillemets des formules, noms d'onglets (les
références sont mises à jour), colonnes de tableaux, commentaires, en-têtes et pieds de page,
liens, validations de données, mises en forme conditionnelles, propriétés du classeur.
Les nombres sont conservés : ce sont les montants à analyser.

Non traités : noms définis et noms de tableaux eux-mêmes (leur syntaxe interdit un code
commençant par un chiffre), graphiques, tableaux croisés dynamiques.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from invisibility_cloak.formats.base import TextTransform, transform_url

_MAX_TITLE_LENGTH = 31
_STRUCTURED_COLUMN = re.compile(r"\[(?!#)([^\[\]]+)\]")
_PROPERTIES = ("title", "subject", "description", "keywords", "category")


class _Rewriter:
    """Applique la transformation aux formules, en suivant les onglets renommés."""

    def __init__(self, transform: TextTransform, titles: dict[str, str]) -> None:
        self.transform = transform
        self.titles = titles

    def reference(self, value: str) -> str:
        """Référence d'une formule : onglet renommé, colonne d'un tableau structuré."""
        if "!" in value:
            sheet, cell = value.rsplit("!", 1)
            names = sheet.removeprefix("'").removesuffix("'").replace("''", "'").split(":")
            if any(name in self.titles for name in names):
                renamed = ":".join(self.titles.get(name, name) for name in names)
                value = "'" + renamed.replace("'", "''") + "'!" + cell
        return _STRUCTURED_COLUMN.sub(lambda m: f"[{self.transform(m.group(1))}]", value)

    def _literal(self, value: str) -> str:
        text = value[1:-1].replace('""', '"')
        return '"' + self.transform(text).replace('"', '""') + '"'

    def formula(self, formula: str) -> str:
        """Formule commençant par « = » : seuls ses textes et ses références changent."""
        from openpyxl.formula import Tokenizer
        from openpyxl.formula.tokenizer import Token

        parts: list[str] = []
        functions: list[str] = []
        previous: Any = None
        for token in Tokenizer(formula).items:
            value = token.value
            if token.subtype == Token.OPEN:
                functions.append(value.upper())
            elif token.subtype == Token.CLOSE and functions:
                functions.pop()
            if token.type == Token.OPERAND and token.subtype == Token.TEXT:
                # Le format de TEXTE(valeur;"jj/mm/aaaa") est une syntaxe, pas une donnée
                is_format = (
                    functions[-1:] == ["TEXT("]
                    and previous is not None
                    and previous.type == Token.SEP
                )
                value = value if is_format else self._literal(value)
            elif token.type == Token.OPERAND and token.subtype == Token.RANGE:
                value = self.reference(value)
            parts.append(value)
            if token.type != Token.WSPACE:
                previous = token
        return "=" + "".join(parts)

    def expression(self, expression: str) -> str:
        """Formule stockée sans « = » (nom défini, validation, mise en forme conditionnelle)."""
        return self.formula(f"={expression}")[1:]


def _fit_title(title: str, taken: set[str]) -> str:
    """Nom d'onglet accepté par Excel : 31 caractères au plus, sans doublon."""
    candidate = title[:_MAX_TITLE_LENGTH]
    index = 0
    while candidate.casefold() in taken:
        index += 1
        suffix = str(index)
        candidate = title[: _MAX_TITLE_LENGTH - len(suffix)] + suffix
    taken.add(candidate.casefold())
    return candidate


def _rename_sheets(workbook: Any, transform: TextTransform) -> dict[str, str]:
    """Renomme les onglets ; renvoie les changements (ancien nom → nouveau nom)."""
    titles: dict[str, str] = {}
    taken: set[str] = set()
    for sheet in [*workbook.worksheets, *workbook.chartsheets]:
        old = sheet.title
        new = _fit_title(transform(old), taken)
        if new != old:
            sheet.title = new
            titles[old] = sheet.title
    return titles


def _transform_cell(cell: Any, transform: TextTransform, rewriter: _Rewriter) -> None:
    from openpyxl.worksheet.formula import ArrayFormula

    value = cell.value
    if isinstance(value, ArrayFormula):
        if value.text:
            value.text = rewriter.formula(value.text)
    elif cell.data_type == "f" and isinstance(value, str):
        cell.value = rewriter.formula(value)
    elif isinstance(value, str) and value.strip():
        cell.value = transform(value)
    if cell.comment is not None:
        cell.comment.text = transform(cell.comment.text)
        cell.comment.author = transform(cell.comment.author or "")
    link = cell.hyperlink
    if link is not None:
        if link.target:
            link.target = transform_url(link.target, transform)
        if link.location:
            link.location = rewriter.reference(link.location)
        if link.tooltip:
            link.tooltip = transform(link.tooltip)
        if link.display:
            link.display = transform(link.display)


def _transform_headers(sheet: Any, transform: TextTransform) -> None:
    for name in (
        "oddHeader",
        "oddFooter",
        "evenHeader",
        "evenFooter",
        "firstHeader",
        "firstFooter",
    ):
        block = getattr(sheet, name)
        for part in (block.left, block.center, block.right):
            if part.text:
                part.text = transform(part.text)


def _transform_filters(filters: Iterable[Any], transform: TextTransform) -> None:
    for auto_filter in filters:
        for column in auto_filter.filterColumn:
            if column.filters is not None:
                column.filters.filter = [transform(value) for value in column.filters.filter]


def _transform_tables(sheet: Any, transform: TextTransform) -> None:
    """Colonnes des tableaux : Excel exige qu'elles restent identiques aux cellules d'en-tête."""
    for table in sheet.tables.values():
        for column in table.tableColumns:
            column.name = transform(column.name)
            if column.totalsRowLabel:
                column.totalsRowLabel = transform(column.totalsRowLabel)
    _transform_filters(
        [sheet.auto_filter, *(t.autoFilter for t in sheet.tables.values() if t.autoFilter)],
        transform,
    )


def _transform_rules(sheet: Any, transform: TextTransform, rewriter: _Rewriter) -> None:
    for validation in sheet.data_validations.dataValidation:
        for name in ("prompt", "promptTitle", "error", "errorTitle"):
            if getattr(validation, name):
                setattr(validation, name, transform(getattr(validation, name)))
        for name in ("formula1", "formula2"):
            if getattr(validation, name):
                setattr(validation, name, rewriter.expression(getattr(validation, name)))
    for formatting in sheet.conditional_formatting:
        for rule in formatting.rules:
            rule.formula = [rewriter.expression(formula) for formula in rule.formula]
            if rule.text:
                rule.text = transform(rule.text)


def _transform_names(names: Any, rewriter: _Rewriter) -> None:
    for name in names.values():
        if name.attr_text:
            name.attr_text = rewriter.expression(name.attr_text)


def _transform_properties(workbook: Any, transform: TextTransform) -> None:
    properties = workbook.properties
    for name in _PROPERTIES:
        if getattr(properties, name):
            setattr(properties, name, transform(getattr(properties, name)))
    properties.creator = ""
    properties.lastModifiedBy = ""
    for custom in workbook.custom_doc_props.props:
        if isinstance(custom.value, str) and custom.value:
            custom.value = transform(custom.value)


class XlsxHandler:
    def transform(self, source: Path, target: Path, transform: TextTransform) -> None:
        import openpyxl

        workbook = openpyxl.load_workbook(str(source))
        rewriter = _Rewriter(transform, _rename_sheets(workbook, transform))
        _transform_names(workbook.defined_names, rewriter)
        for sheet in workbook.worksheets:
            for row in sheet.iter_rows():
                for cell in row:
                    _transform_cell(cell, transform, rewriter)
            _transform_headers(sheet, transform)
            _transform_tables(sheet, transform)
            _transform_rules(sheet, transform, rewriter)
            _transform_names(sheet.defined_names, rewriter)
        _transform_properties(workbook, transform)
        workbook.save(str(target))


HANDLER = XlsxHandler()
