"""Documents Word (.docx) via python-docx.

Tout le texte est transformé : corps, tableaux, zones de texte, en-têtes, pieds de page, notes,
commentaires, révisions, liens, textes de remplacement des images et propriétés du document.
Un nom pouvant être éclaté sur plusieurs « runs », le texte est traité par suite de runs
contiguës, réunie dans la première : une mise en forme partielle à l'intérieur de cette suite
est perdue. Tabulations, sauts de ligne, images et liens séparent ces suites et restent en place.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from invisibility_cloak.formats.base import TextTransform, transform_url

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_W15 = "{http://schemas.microsoft.com/office/word/2012/wordml}"
_XML_SPACE = "{http://www.w3.org/XML/1998/namespace}space"
_TEXT_TAGS = {f"{_W}t", f"{_W}delText"}
_TEXT_PARTS = re.compile(
    r"/word/(glossary/)?"
    r"(document|header\d*|footer\d*|footnotes|endnotes|comments|people)\.xml"
)
# Auteurs des révisions et commentaires ; textes de remplacement des images et formes
_TEXT_ATTRIBUTES = {
    f"{_W}author",
    f"{_W}initials",
    f"{_W15}author",
    f"{_W15}userId",
    "descr",
    "title",
    "alt",
}
_PROPERTY_PARTS = {"/docProps/app.xml", "/docProps/custom.xml"}
_PROPERTY_TAGS = {"Company", "Manager", "HyperlinkBase", "lpwstr"}
_CORE_PROPERTIES = ("title", "subject", "comments", "keywords", "category")
_CORE_PROPERTY_MAX_LENGTH = 255
_HYPERLINK_RELATIONSHIP = "/hyperlink"
_THUMBNAIL_RELATIONSHIP = "/thumbnail"


def _segments(paragraph: Any) -> list[list[Any]]:
    """Éléments de texte du paragraphe, regroupés par suite de runs contiguës."""
    segments: list[list[Any]] = []
    current: list[Any] = []
    previous_parent = None
    for run in paragraph.iter(f"{_W}r"):
        # Une zone de texte contient ses propres paragraphes, traités à part
        if next(run.iterancestors(f"{_W}p"), None) is not paragraph:
            continue
        if run.getparent() is not previous_parent:
            current = []
            segments.append(current)
            previous_parent = run.getparent()
        for child in run:
            if child.tag in _TEXT_TAGS:
                current.append(child)
            elif child.tag != f"{_W}rPr":
                current = []
                segments.append(current)
    return segments


def _transform_paragraph(paragraph: Any, transform: TextTransform) -> None:
    for elements in _segments(paragraph):
        text = "".join(element.text or "" for element in elements)
        if not text.strip():
            continue
        new_text = transform(text)
        if new_text != text:
            elements[0].text = new_text
            elements[0].set(_XML_SPACE, "preserve")
            for element in elements[1:]:
                element.text = ""


def _hyperlink_field(instruction: str, transform: TextTransform) -> str:
    """Adresse d'un champ HYPERLINK ; les autres champs ont une syntaxe à conserver."""
    if "HYPERLINK" not in instruction or "\\l" in instruction:
        return instruction
    return re.sub(r'"([^"]*)"', lambda m: f'"{transform_url(m.group(1), transform)}"', instruction)


def _transform_text_part(root: Any, transform: TextTransform) -> None:
    for paragraph in root.iter(f"{_W}p"):
        _transform_paragraph(paragraph, transform)
    for instruction in root.iter(f"{_W}instrText"):
        instruction.text = _hyperlink_field(instruction.text or "", transform)
    for element in root.iter():
        if not isinstance(element.tag, str):
            continue
        for name in _TEXT_ATTRIBUTES.intersection(element.attrib):
            element.set(name, transform(element.get(name)))
        if element.tag == f"{_W}fldSimple" and element.get(f"{_W}instr"):
            element.set(f"{_W}instr", _hyperlink_field(element.get(f"{_W}instr"), transform))


def _transform_property_part(root: Any, transform: TextTransform) -> None:
    for element in root.iter():
        if (
            isinstance(element.tag, str)
            and element.tag.rpartition("}")[2] in _PROPERTY_TAGS
            and element.text
        ):
            element.text = transform(element.text)


def _transform_part(part: Any, transform: TextTransform) -> None:
    from docx.opc.oxml import serialize_part_xml
    from docx.opc.part import XmlPart
    from docx.oxml import parse_xml

    name = str(part.partname)
    is_text = _TEXT_PARTS.fullmatch(name) is not None
    if not is_text and name not in _PROPERTY_PARTS:
        return
    is_xml_part = isinstance(part, XmlPart)
    root = part.element if is_xml_part else parse_xml(part.blob)
    if is_text:
        _transform_text_part(root, transform)
        for relationship in part.rels.values():
            if relationship.is_external and relationship.reltype.endswith(_HYPERLINK_RELATIONSHIP):
                relationship._target = transform_url(relationship._target, transform)
    else:
        _transform_property_part(root, transform)
    if not is_xml_part:
        part._blob = serialize_part_xml(root)


class DocxHandler:
    def transform(self, source: Path, target: Path, transform: TextTransform) -> None:
        import docx  # import local : dépendance chargée seulement si besoin

        document = docx.Document(str(source))
        package = document.part.package
        for part in package.iter_parts():
            _transform_part(part, transform)
        # L'aperçu enregistré par Word montre la première page en clair
        for key, relationship in list(package.rels.items()):
            if relationship.reltype.endswith(_THUMBNAIL_RELATIONSHIP):
                del package.rels[key]
        properties = document.core_properties
        for name in _CORE_PROPERTIES:
            value = getattr(properties, name)
            if value:
                setattr(properties, name, transform(value)[:_CORE_PROPERTY_MAX_LENGTH])
        properties.author = ""
        properties.last_modified_by = ""
        document.save(str(target))


HANDLER = DocxHandler()
