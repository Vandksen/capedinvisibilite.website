"""Interface commune aux gestionnaires de formats."""

from __future__ import annotations

import re
from collections.abc import Callable
from pathlib import Path
from typing import Protocol

TextTransform = Callable[[str], str]

_URL_SCHEME = re.compile(r"[A-Za-z][A-Za-z0-9+.-]*:(?://)?")


def transform_url(url: str, transform: TextTransform) -> str:
    """Transforme une adresse en gardant son protocole : sans lui, le lien serait invalide."""
    match = _URL_SCHEME.match(url)
    scheme = match.group(0) if match else ""
    return scheme + transform(url[len(scheme) :])


class FormatHandler(Protocol):
    """Lit un fichier, applique `transform` à chaque fragment de texte, réécrit le fichier."""

    def transform(self, source: Path, target: Path, transform: TextTransform) -> None: ...
