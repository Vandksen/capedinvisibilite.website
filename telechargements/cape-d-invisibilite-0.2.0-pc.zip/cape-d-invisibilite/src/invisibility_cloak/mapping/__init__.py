"""Table de correspondance et désanonymisation."""
