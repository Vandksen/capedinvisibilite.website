"""Cape d'invisibilité — pseudonymisation locale de fichiers avant usage de l'IA."""

# Seule source du numéro de version (MAJEUR.MINEUR.CORRECTIF) : pyproject.toml le lit ici.
# À chaque version livrée : changer ce numéro et ajouter son entrée dans CHANGELOG.md.
__version__ = "0.2.0"
# Étape de diffusion affichée à côté du numéro (vide une fois la version stable publiée)
RELEASE_STAGE = "bêta"
