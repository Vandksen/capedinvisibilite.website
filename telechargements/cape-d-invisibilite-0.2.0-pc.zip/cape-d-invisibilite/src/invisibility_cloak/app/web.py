"""Interface web locale : une page servie par Flask, sur ce poste uniquement.

L'utilisateur dépose un ou plusieurs fichiers (Word, Excel, FEC) dans la page, éventuellement
avec une table existante à compléter ; le navigateur télécharge une archive ZIP qui contient
les fichiers pseudonymisés et leur table de correspondance : un classeur Excel en clair
(`.xlsx`), ou chiffré par un mot de passe s'il en a choisi un (`.map`). La seconde partie de
la page rétablit les vraies valeurs à partir d'un fichier et de sa table. Rien n'est conservé
sur le disque et le serveur n'écoute que sur 127.0.0.1 : il est inaccessible depuis le réseau.

Lancement : `Lancer Cape d'invisibilite` (.bat sur PC, .command sur Mac).
"""

from __future__ import annotations

import argparse
import io
import threading
import webbrowser
import zipfile
from pathlib import PurePath

from flask import Flask, Response, abort, jsonify, render_template, request, send_file

from invisibility_cloak import RELEASE_STAGE, __version__
from invisibility_cloak.core import anonymize_bytes, restore_bytes, table_name
from invisibility_cloak.errors import CloakError
from invisibility_cloak.mapping.table import Mapping

HOST = "127.0.0.1"
# Même port sur Mac et sur PC ; sur Mac, le port 5000 est souvent pris par AirPlay
DEFAULT_PORT = 5055
# Un FEC de grosse société dépasse vite 100 Mo
MAX_UPLOAD_BYTES = 500 * 1024 * 1024
# Noms d'hôte acceptés : bloque une page web distante qui viserait ce serveur
# par rebinding DNS (son nom d'hôte ne serait pas l'un de ceux-ci)
LOCAL_HOSTS = {"127.0.0.1", "localhost"}
# Site vitrine : un simple lien que l'utilisateur ouvre lui-même, la page n'y fait aucun appel
SITE_URL = "https://www.capedinvisibilite.fr"


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_BYTES

    @app.before_request
    def local_only() -> None:
        if request.host.rsplit(":", 1)[0] not in LOCAL_HOSTS:
            abort(403)

    @app.get("/")
    def index() -> str:
        return render_template(
            "index.html", version=__version__, release_stage=RELEASE_STAGE, site_url=SITE_URL
        )

    @app.post("/anonymiser")
    def anonymiser() -> Response | tuple[Response, int]:
        uploads = [f for f in request.files.getlist("fichier") if f.filename]
        if not uploads:
            return _error("Aucun fichier reçu.", 400)
        password = request.form.get("mot_de_passe", "")
        existing = request.files.get("table")
        try:
            # Une table existante est complétée : mêmes pseudonymes, même référence
            mapping = (
                Mapping.read(existing.read(), password)
                if existing and existing.filename
                else Mapping()
            )
            outputs = []
            for index, upload in enumerate(uploads, start=1):
                content = upload.read()
                if Mapping.is_table(content):
                    raise CloakError(
                        _numbered(
                            index,
                            len(uploads),
                            "c'est une table de correspondance : "
                            "déposez-la dans « Table existante » pour la compléter.",
                        )
                    )
                try:
                    outputs.append(anonymize_bytes(str(upload.filename), content, mapping)[:2])
                except CloakError as error:
                    raise CloakError(_numbered(index, len(uploads), str(error))) from None
            table_suffix, table = mapping.export(password)
        except CloakError as error:
            return _error(str(error), 400)
        except Exception:  # noqa: BLE001 — toute erreur, sans en divulguer le détail
            # Message générique : le détail pourrait contenir une valeur du fichier
            return _error("Le fichier n'a pas pu être traité.", 500)
        files = [*outputs, (table_name(mapping, table_suffix), table)]
        if len(outputs) == 1:
            archive = f"{PurePath(outputs[0][0]).stem}.zip"
        else:
            archive = table_name(mapping, ".zip").replace("table-", "cape-", 1)
        response = send_file(
            io.BytesIO(_bundle(files)),
            as_attachment=True,
            download_name=archive,
            mimetype="application/zip",
        )
        response.headers["X-Cloak-Table"] = mapping.ref
        return response

    @app.post("/desanonymiser")
    def desanonymiser() -> Response | tuple[Response, int]:
        upload = request.files.get("fichier")
        table = request.files.get("table")
        if upload is None or not upload.filename:
            return _error("Aucun fichier à rétablir reçu.", 400)
        if table is None or not table.filename:
            return _error("Ajoutez la table de correspondance (.xlsx ou .map).", 400)
        password = request.form.get("mot_de_passe", "")
        try:
            mapping = Mapping.read(table.read(), password)
            name, content, exact = restore_bytes(upload.filename, upload.read(), mapping)
        except CloakError as error:
            return _error(str(error), 400)
        except Exception:  # noqa: BLE001 — toute erreur, sans en divulguer le détail
            return _error("Le fichier n'a pas pu être rétabli.", 500)
        response = send_file(
            io.BytesIO(content),
            as_attachment=True,
            download_name=name,
            mimetype="application/octet-stream",
        )
        response.headers["X-Cloak-Identique"] = "1" if exact else "0"
        return response

    @app.errorhandler(413)
    def too_large(_exception: Exception) -> tuple[Response, int]:
        return _error(f"Fichier trop volumineux (maximum {MAX_UPLOAD_BYTES // 1024**2} Mo).", 413)

    return app


def _bundle(files: list[tuple[str, bytes]]) -> bytes:
    """Archive ZIP des fichiers pseudonymisés et de leur table, construite en mémoire."""
    buffer = io.BytesIO()
    names: set[str] = set()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, content in files:
            # Deux fichiers de même nom, traités dans la même seconde : le second est numéroté
            unique, rank = name, 1
            while unique in names:
                rank += 1
                path = PurePath(name)
                unique = f"{path.stem}-{rank}{path.suffix}"
            names.add(unique)
            archive.writestr(unique, content)
    return buffer.getvalue()


def _numbered(index: int, total: int, message: str) -> str:
    """Message d'erreur qui situe le fichier en cause sans citer son nom (il peut être sensible)."""
    return message if total == 1 else f"Fichier n° {index} : {message}"


def _error(message: str, status: int) -> tuple[Response, int]:
    return jsonify(erreur=message), status


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Cape d'invisibilité — page web locale")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--no-browser", action="store_true", help="Ne pas ouvrir le navigateur")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    args = parser.parse_args(argv)

    url = f"http://{HOST}:{args.port}/"
    if not args.no_browser:
        threading.Timer(1.0, webbrowser.open, args=(url,)).start()
    print(
        f"Cape d'invisibilité {__version__} est ouvert sur {url} — fermez cette fenêtre pour l'arrêter."
    )
    create_app().run(host=HOST, port=args.port, debug=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
