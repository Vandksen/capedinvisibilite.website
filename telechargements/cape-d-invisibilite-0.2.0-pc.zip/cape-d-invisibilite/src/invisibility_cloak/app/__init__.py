"""Interfaces utilisateur : CLI d'abord, interface graphique ensuite."""
