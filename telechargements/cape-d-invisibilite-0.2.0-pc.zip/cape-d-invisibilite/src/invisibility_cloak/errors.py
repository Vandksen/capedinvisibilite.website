"""Exceptions du projet. Aucun message ne doit contenir de valeur sensible."""

from __future__ import annotations


class CloakError(Exception):
    """Erreur de base de Cape d'invisibilité."""


class UnsupportedFormatError(CloakError):
    """Format de fichier non pris en charge."""


class EngineNotAvailableError(CloakError):
    """Le moteur d'anonymisation n'est pas encore branché dans engine/."""


class MappingError(CloakError):
    """Table de correspondance illisible, corrompue ou mauvaise clé."""
