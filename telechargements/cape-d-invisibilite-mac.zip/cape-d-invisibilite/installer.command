#!/bin/bash
# Installation, une seule fois, de Cape d'invisibilité sur Mac. Équivalent PC : installer.bat
# Nécessite Python 3.11 ou plus récent : https://www.python.org/downloads/macos/
cd "$(dirname "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

pause_if_interactive() {
    if [ -t 0 ]; then read -r -p "Appuyez sur Entrée pour fermer..."; fi
}

fail() {
    echo "$1"
    pause_if_interactive
    exit 1
}

PYTHON=""
for candidate in python3.14 python3.13 python3.12 python3.11 python3; do
    if command -v "$candidate" >/dev/null 2>&1 &&
        "$candidate" -c "import sys; sys.exit(sys.version_info < (3, 11))" >/dev/null 2>&1; then
        PYTHON="$candidate"
        break
    fi
done
[ -n "$PYTHON" ] || fail "Python 3.11 ou plus récent est introuvable. Installez-le, puis relancez ce fichier."

"$PYTHON" -m venv .venv || fail "La création de l'environnement a échoué."
.venv/bin/python -m pip install -r requirements.txt || fail "L'installation a échoué."

echo
echo "Installation terminée. Lancez « Lancer Cape d'invisibilite.command »."
pause_if_interactive
