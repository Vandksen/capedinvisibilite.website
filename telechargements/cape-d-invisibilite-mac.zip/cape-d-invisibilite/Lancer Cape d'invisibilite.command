#!/bin/bash
# Démarre la page web locale et ouvre le navigateur. Équivalent PC : Lancer Cape d'invisibilite.bat
# Fermer cette fenêtre arrête l'application.
cd "$(dirname "$0")" || exit 1

if [ ! -x .venv/bin/python ]; then
    echo "Cape d'invisibilité n'est pas installé. Lancez d'abord installer.command."
    if [ -t 0 ]; then read -r -p "Appuyez sur Entrée pour fermer..."; fi
    exit 1
fi

exec .venv/bin/python -m invisibility_cloak.app.web
