"""Table de correspondance valeur d'origine ↔ pseudonyme.

Son contenu est celui de la table du moteur : formes exactes des mots et des numéros, avec
leurs occurrences, et pour chaque FEC le nom, l'empreinte, le SIREN et les champs enregistrés en
entier. Une même table couvre plusieurs fichiers : avec la même clé, une valeur garde le même
pseudonyme d'un fichier à l'autre, et l'IA peut les combiner.

Seule l'enveloppe diffère de celle du moteur :

- sans mot de passe, un classeur Excel en clair (`.xlsx`), lisible par l'utilisateur ;
- avec un mot de passe, un fichier chiffré (`.map`, Fernet, clé dérivée du mot de passe).

Chaque table a une référence de 6 caractères hexadécimaux (« 3f9a1c »), tirée de sa clé : elle est
reprise dans le nom de la table et de chaque fichier pseudonymisé avec elle.
"""

from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import os
import secrets
import zipfile
from collections import Counter
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from invisibility_cloak import engine_adapter
from invisibility_cloak.errors import MappingError

# Extensions des deux enveloppes de la table
CLEAR_SUFFIX = ".xlsx"
ENCRYPTED_SUFFIX = ".map"
# Longueur de la référence de la table, comme un identifiant de commit court
REF_LENGTH = 6
# Version du contenu des enveloppes écrites ici (le format des lignes reste celui du moteur)
ENVELOPE_VERSION = 2

_SHEET_WORDS = "Correspondances"
_SHEET_SETTINGS = "Paramètres"
_SHEET_FEC = "FEC {}"
_HEADERS = ["Type", "Valeur d'origine", "Pseudonyme", "Occurrences", "Position"]
_ZIP_MAGIC = b"PK\x03\x04"


@dataclass
class Mapping:
    # Clé du moteur : avec la même table, une même valeur garde le même pseudonyme
    # d'un fichier à l'autre. Enregistrée avec la table (chiffrée si un mot de passe est choisi).
    secret: str = field(default_factory=lambda: secrets.token_hex(32), repr=False)
    # Tous les mots et numéros remplacés, tous fichiers confondus
    words: Counter[tuple[str, str]] = field(default_factory=Counter, repr=False)
    numbers: Counter[tuple[str, str]] = field(default_factory=Counter, repr=False)
    # Une table du moteur complète par FEC : il se rétablit à l'octet près avec la sienne seule
    fecs: list[dict[str, Any]] = field(default_factory=list, repr=False)

    @property
    def ref(self) -> str:
        """Référence de la table (« 3f9a1c »), stable : elle ne dépend que de la clé."""
        return hashlib.sha256(bytes.fromhex(self.secret)).hexdigest()[:REF_LENGTH]

    @property
    def file(self) -> tuple[str, str] | None:
        """Nom d'origine et nom pseudonymisé du premier FEC de la table."""
        return self.fecs[0]["fichier"] if self.fecs else None

    def known_values(self) -> list[str]:
        return [original for original, _ in (*self.words, *self.numbers)]

    def sirens(self) -> dict[str, str]:
        """SIREN d'origine → SIREN fictif, pour les FEC de la table."""
        return {t["siren"][0]: t["siren"][1] for t in self.fecs if t.get("siren")}

    # --- contenu ----------------------------------------------------------------

    def to_table(self) -> dict[str, Any]:
        """Table au format du moteur pour rétablir un texte : tous les mots et numéros.

        Avec un seul FEC, elle porte aussi son nom, son empreinte et ses champs : c'est alors la
        table que le moteur aurait écrite.
        """
        numbers = Counter(self.numbers)
        for original, fictive in list(self.sirens().items())[1:]:
            numbers[(original, fictive)] += 1
        single = self.fecs[0] if len(self.fecs) == 1 else None
        return {
            "fichier": single["fichier"] if single else None,
            "empreinte": single["empreinte"] if single else None,
            "siren": self.fecs[0]["siren"] if self.fecs else None,
            "mots": [(o, p, n) for (o, p), n in sorted(self.words.items())],
            "nombres": [(o, p, n) for (o, p), n in sorted(numbers.items())],
            "champs": dict(single["champs"]) if single else {},
        }

    def absorb(self, table: dict[str, Any]) -> None:
        """Ajoute le contenu d'une table du moteur (celle d'un FEC est aussi gardée en entier)."""
        for original, pseudonym, count in table["mots"]:
            self.words[(original, pseudonym)] += count
        for original, pseudonym, count in table["nombres"]:
            self.numbers[(original, pseudonym)] += count
        if table.get("fichier") and not any(
            t["empreinte"] == table["empreinte"] for t in self.fecs
        ):
            self.fecs.append(table)

    def restore(self, text: str) -> str:
        return self.restorer()(text)

    def restorer(self) -> Callable[[str], str]:
        """Rétablissement à réutiliser pour tous les fragments d'un fichier (Word, Excel)."""
        restore = engine_adapter.text_restorer(self.to_table())
        # SIREN masqué du nom des autres FEC (« 97_____65 ») : le moteur n'en connaît qu'un
        masked = [
            (engine_adapter.masked_siren(original), original)
            for original in list(self.sirens())[1:]
        ]

        def restore_all(text: str) -> str:
            for pseudonym, original in masked:
                text = text.replace(pseudonym, original)
            return restore(text)

        return restore_all

    def restore_content(self, content: bytes) -> tuple[bytes, bool]:
        """Contenu rétabli, et s'il est garanti identique à l'origine (FEC de la table)."""
        for table in self.fecs:
            if engine_adapter.is_pseudonymized_fec(content, table):
                return engine_adapter.restore_content(content, table)
        return engine_adapter.restore_content_as_text(content, self.restorer())

    def original_fec_name(self, content: bytes) -> str | None:
        """Nom d'origine du FEC de la table dont `content` est la version pseudonymisée."""
        for table in self.fecs:
            if engine_adapter.is_pseudonymized_fec(content, table):
                return str(table["fichier"][0])
        return None

    # --- enveloppes ---------------------------------------------------------------

    def export(self, password: str) -> tuple[str, bytes]:
        """Extension et contenu de la table : chiffrée avec un mot de passe, en clair sinon."""
        if password:
            return ENCRYPTED_SUFFIX, self.to_bytes(password)
        return CLEAR_SUFFIX, self.to_xlsx()

    @classmethod
    def read(cls, raw: bytes, password: str = "") -> Mapping:
        """Relit une table, en clair (.xlsx) ou chiffrée (.map) : le contenu le dit."""
        if raw.startswith(_ZIP_MAGIC):
            return cls.from_xlsx(raw)
        return cls.from_bytes(raw, password)

    @classmethod
    def is_table(cls, raw: bytes) -> bool:
        """`raw` est-il une table en clair (classeur écrit par `to_xlsx`) ?"""
        if not raw.startswith(_ZIP_MAGIC):
            return False
        try:
            cls.from_xlsx(raw)
        except MappingError:
            return False
        return True

    def _payload(self) -> dict[str, Any]:
        words_only: dict[str, Any] = {
            "fichier": None,
            "empreinte": None,
            "siren": None,
            "mots": [(o, p, n) for (o, p), n in sorted(self.words.items())],
            "nombres": [(o, p, n) for (o, p), n in sorted(self.numbers.items())],
            "champs": {},
        }
        return {
            "version": ENVELOPE_VERSION,
            "secret": self.secret,
            "table": engine_adapter.table_to_text(words_only),
            "fecs": [engine_adapter.table_to_text(t) for t in self.fecs],
        }

    @classmethod
    def _from_payload(cls, data: dict[str, Any]) -> Mapping:
        mapping = cls(secret=data["secret"])
        table = engine_adapter.text_to_table(data["table"])
        if "fecs" not in data:
            # Table d'avant la version 2 : un seul texte, FEC compris
            mapping.absorb(table)
            return mapping
        mapping.absorb(table)
        mapping.fecs = [engine_adapter.text_to_table(text) for text in data["fecs"]]
        return mapping

    # Chiffrée (.map)

    def save(self, path: Path, password: str) -> None:
        path.write_bytes(self.to_bytes(password))

    def to_bytes(self, password: str) -> bytes:
        """Table chiffrée, telle qu'écrite par `save` (lisible par `load`)."""
        from cryptography.fernet import Fernet

        salt = os.urandom(16)
        token = Fernet(_derive_key(password, salt)).encrypt(json.dumps(self._payload()).encode())
        return salt + token

    @classmethod
    def load(cls, path: Path, password: str = "") -> Mapping:
        return cls.read(path.read_bytes(), password)

    @classmethod
    def from_bytes(cls, raw: bytes, password: str) -> Mapping:
        """Relit une table chiffrée par `to_bytes` ou `save`."""
        from cryptography.fernet import Fernet, InvalidToken

        salt, token = raw[:16], raw[16:]
        try:
            data = json.loads(Fernet(_derive_key(password, salt)).decrypt(token))
        except (InvalidToken, ValueError):
            raise MappingError("Mot de passe incorrect ou table corrompue") from None
        return cls._from_payload(data)

    # En clair (.xlsx)

    def to_xlsx(self) -> bytes:
        """Classeur en clair : une feuille des correspondances, une par FEC, les paramètres."""
        from openpyxl import Workbook
        from openpyxl.styles import Font
        from openpyxl.utils.exceptions import IllegalCharacterError

        from invisibility_cloak import __version__

        payload = self._payload()
        workbook = Workbook()
        sheets: list[tuple[Any, str, str]] = [(workbook.active, _SHEET_WORDS, payload["table"])]
        for index, text in enumerate(payload["fecs"], start=1):
            sheets.append((workbook.create_sheet(), _SHEET_FEC.format(index), text))
        try:
            for sheet, title, text in sheets:
                sheet.title = title
                sheet.append(_HEADERS)
                for row in csv.reader(io.StringIO(text, newline=""), delimiter=";"):
                    if row and row[0] != "type":
                        _append_text_row(sheet, row)
        except IllegalCharacterError:
            raise MappingError(
                "La table contient des caractères qu'un classeur Excel ne peut pas enregistrer : "
                "choisissez un mot de passe pour obtenir une table chiffrée (.map)."
            ) from None
        settings = workbook.create_sheet(_SHEET_SETTINGS)
        rows: tuple[tuple[str, object], ...] = (
            ("Référence", self.ref),
            ("Clé", self.secret),
            ("Version de la table", ENVELOPE_VERSION),
            ("Application", f"Cape d'invisibilité {__version__}"),
            ("", ""),
            (
                "Attention",
                "Cette table rétablit les vraies valeurs : ne l'envoyez jamais à une IA.",
            ),
            ("", "Ne modifiez ni la clé ni les pseudonymes : la table ne se relirait plus."),
        )
        for setting in rows:
            settings.append(setting)
        for sheet, *_ in sheets:
            for cell in sheet[1]:
                cell.font = Font(bold=True)
            sheet.freeze_panes = "A2"
            for column, width in zip("ABCDE", (12, 40, 24, 13, 12), strict=True):
                sheet.column_dimensions[column].width = width
        settings.column_dimensions["A"].width = 22
        settings.column_dimensions["B"].width = 70
        output = io.BytesIO()
        workbook.save(output)
        return output.getvalue()

    @classmethod
    def from_xlsx(cls, raw: bytes) -> Mapping:
        """Relit un classeur écrit par `to_xlsx`."""
        from openpyxl import load_workbook

        try:
            workbook = load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
            settings = {
                str(row[0]): row[1]
                for row in workbook[_SHEET_SETTINGS].iter_rows(values_only=True)
                if row and row[0]
            }
            secret = str(settings["Clé"])
            bytes.fromhex(secret)
            data: dict[str, Any] = {"secret": secret, "table": "", "fecs": []}
            for sheet in workbook.worksheets:
                if sheet.title == _SHEET_SETTINGS:
                    continue
                text = _sheet_to_text(sheet)
                if sheet.title == _SHEET_WORDS:
                    data["table"] = text
                else:
                    data["fecs"].append(text)
            workbook.close()
        except (KeyError, ValueError, OSError, TypeError, zipfile.BadZipFile):
            raise MappingError(
                "Ce classeur n'est pas une table de correspondance de Cape d'invisibilité."
            ) from None
        return cls._from_payload(data)


def _append_text_row(sheet: Any, row: list[str]) -> None:
    """Ligne de la table ; les textes restent des textes (« =… » n'est pas une formule)."""
    values: list[object] = list(row)
    if len(row) > 3 and row[3].isdigit():
        values[3] = int(row[3])
    sheet.append(values)
    for cell in sheet[sheet.max_row]:
        if isinstance(cell.value, str):
            cell.data_type = "s"


def _sheet_to_text(sheet: Any) -> str:
    """Feuille relue au format texte du moteur (CSV « ; »)."""
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter=";")
    writer.writerow(["type", "original", "pseudonyme", "occurrences", "position"])
    for index, row in enumerate(sheet.iter_rows(values_only=True)):
        if index == 0 or not row or row[0] is None:
            continue
        cells = ["" if value is None else str(value) for value in row[:5]]
        writer.writerow(cells + [""] * (5 - len(cells)))
    return output.getvalue()


def _derive_key(password: str, salt: bytes) -> bytes:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=600_000)
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))
