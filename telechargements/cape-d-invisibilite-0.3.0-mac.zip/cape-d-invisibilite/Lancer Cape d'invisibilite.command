#!/bin/bash
# Démarre la page web locale et ouvre le navigateur. Équivalent PC : Lancer Cape d'invisibilite.bat
# Fermer cette fenêtre arrête l'application.
cd "$(dirname "$0")" || exit 1

# Bannière ASCII (packaging/banniere.ascii), en bleu si le terminal l'accepte.
show_banner() {
    [ -f packaging/banniere.ascii ] || return 0
    if [ -t 1 ] && [ -z "${NO_COLOR:-}" ] && [ "${TERM:-dumb}" != dumb ]; then
        printf '\033[1;38;5;27m'
        cat packaging/banniere.ascii
        printf '\033[0m'
    else
        cat packaging/banniere.ascii
    fi
}
show_banner

if [ ! -x .venv/bin/python ]; then
    echo "Cape d'invisibilité n'est pas installé. Lancez d'abord installer.command."
    if [ -t 0 ]; then read -r -p "Appuyez sur Entrée pour fermer..."; fi
    exit 1
fi

exec .venv/bin/python -m invisibility_cloak.app.web
