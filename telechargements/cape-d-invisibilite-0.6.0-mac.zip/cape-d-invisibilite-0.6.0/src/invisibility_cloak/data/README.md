# data/

Listes de mots du mode « texte rédigé » (Word, Excel), lues par `engine_adapter.py`.
Aucune donnée client. Le FEC ne les utilise pas : il garde le lexique du moteur seul.

| Fichier | Rôle | Source et licence |
| --- | --- | --- |
| `francais.txt` | Français général : ces mots restent lisibles | Lexique 3.83, http://www.lexique.org, CC BY-SA 4.0 |
| `mots-outils.txt` | Articles, pronoms, prépositions, titres de civilité | Lexique 3.83, CC BY-SA 4.0 |
| `prenoms.txt` | Prénoms : masqués dès qu'ils portent une majuscule | INSEE, fichier des prénoms, Licence Ouverte 2.0 |
| `noms-de-famille.txt` | Noms de famille qui sont aussi des mots courants : masqués dès qu'ils portent une majuscule | INSEE, fichier des noms de famille, Licence Ouverte 2.0 |
| `mots-ajoutes.txt` | Sigles, vocabulaire du métier et titres courants d'un document, tenu à la main | Projet (MIT) |

Les quatre premiers sont produits par `packaging/construire_dictionnaire.py` à partir des fichiers
sources, téléchargés une fois par la personne qui les régénère. L'application ne télécharge rien.

Les fichiers tirés de Lexique 3.83 restent sous CC BY-SA 4.0 (New, Pallier, Brysbaert, Ferrand,
2004) : ils sont livrés tels quels, à côté du code sous licence MIT.
