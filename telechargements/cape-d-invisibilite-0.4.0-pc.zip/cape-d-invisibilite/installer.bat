@echo off
rem Installation, une seule fois, de Cape d'invisibilite sur PC. Equivalent Mac : installer.command
rem Necessite Python 3.11 ou plus recent : https://www.python.org/downloads/
chcp 65001 >nul
cd /d "%~dp0"

rem Banniere ASCII (packaging\banniere.ascii), en bleu sauf si NO_COLOR est defini.
if not exist "packaging\banniere.ascii" goto :apres_banniere
if defined NO_COLOR goto :banniere_sans_couleur
for /f %%e in ('echo prompt $E^| cmd') do set "ESC=%%e"
<nul set /p "=%ESC%[1;38;5;27m"
type "packaging\banniere.ascii"
<nul set /p "=%ESC%[0m"
goto :apres_banniere
:banniere_sans_couleur
type "packaging\banniere.ascii"
:apres_banniere

rem Python 3.11+ : le lanceur py d'abord, sinon python (Python du Microsoft Store)
set "PYTHON="
py -3 -c "import sys; sys.exit(sys.version_info < (3, 11))" >nul 2>&1
if not errorlevel 1 set "PYTHON=py -3"
if not defined PYTHON (
    python -c "import sys; sys.exit(sys.version_info < (3, 11))" >nul 2>&1
    if not errorlevel 1 set "PYTHON=python"
)
if not defined PYTHON (
    echo Python 3.11 ou plus recent est introuvable. Installez-le, puis relancez ce fichier.
    pause
    exit /b 1
)

%PYTHON% -m venv .venv
if errorlevel 1 (
    echo La creation de l'environnement a echoue.
    pause
    exit /b 1
)

.venv\Scripts\python -m pip install -r requirements.txt
if errorlevel 1 (
    echo L'installation a echoue.
    pause
    exit /b 1
)

echo.
echo Installation terminee. Lancez "Lancer Cape d'invisibilite.bat".
pause
