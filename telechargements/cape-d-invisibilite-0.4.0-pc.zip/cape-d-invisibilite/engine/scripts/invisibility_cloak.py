"""Outil d'anonymisation des FEC (Cape d'invisibilité).

Produit une copie anonymisée d'un fichier des écritures comptables (FEC), utilisable pour
les tests et l'entraînement d'Ariane sans exposer le client ni ses tiers :

- le SIREN (nom du fichier et toute mention dans les champs) est remplacé par un SIREN fictif ;
- dans les champs de texte (libellés de journal, de compte, de tiers et d'écriture, numéros
  de tiers, références de pièces, colonnes non standard), chaque mot qui n'appartient pas au
  vocabulaire comptable (lexique) est remplacé par un code de 7 caractères hexadécimaux, sur
  le modèle d'un identifiant court de commit Git (« 3f9a1c2 »), toujours le même pour un
  même mot : un tiers cité dans un libellé d'écriture et dans un libellé de compte garde un
  seul pseudonyme, ce qui préserve les rapprochements par le libellé des contrôles ;
- les suites de cinq chiffres ou plus (numéros de facture, de client, SIRET…), les numéros de
  téléphone et les IBAN sont remplacés par des chiffres fictifs, de façon cohérente ; les montants
  à une ou deux décimales (« 12345,67 ») sont conservés.

Le FEC anonymisé s'appelle <SIREN masqué>FEC<clôture>.txt (« 97_____65FEC20241231.txt » : deux
premiers et deux derniers chiffres du SIREN). La table de correspondance est toujours écrite,
<SIREN>FEC<clôture>-cloak-table.csv à côté du FEC anonymisé (ou au chemin de --correspondance). Elle permet de lever l'anonymat (skill remove-cloak) : formes
exactes des mots et des numéros remplacés, et, pour les rares champs qu'elles ne suffisent pas à
rétablir (deux graphies d'un même mot, « Société » et « Societe »), la valeur d'origine du champ.

Les numéros de compte (partie numérique), les dates, les montants, les codes journaux, les
numéros d'écriture et le lettrage sont conservés : les contrôles donnent les mêmes résultats
sur le FEC anonymisé que sur l'original. Le fichier garde son encodage, son séparateur et
ses fins de ligne.

L'outil est autonome : il ne dépend que de la bibliothèque standard de Python
(charset-normalizer est utilisé s'il est installé, pour un encodage douteux).

Exemples (depuis la racine du projet) :
    python .claude/skills/invisibility-cloak/scripts/invisibility_cloak.py --fec "<FEC>"
    python .claude/skills/invisibility-cloak/scripts/invisibility_cloak.py --fec "<FEC>" --sortie <dossier> --cle "<phrase secrète>"
    python .claude/skills/invisibility-cloak/scripts/invisibility_cloak.py --construire-lexique doc/PCG--1er-janvier-2026.txt doc/Plan-de-comptes-2026.txt
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import hmac
import io
import os
import re
import secrets
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

DOSSIER_SKILL = Path(__file__).resolve().parent.parent
LEXIQUE_PCG = DOSSIER_SKILL / 'references' / 'lexique-pcg.txt'
MOTS_CONSERVES = DOSSIER_SKILL / 'references' / 'mots-conserves.txt'
# Mots propres au projet qui embarque le moteur (facultatif, absent du dépôt du moteur)
MOTS_LOCAUX = DOSSIER_SKILL / 'references' / 'mots-locaux.txt'
# Mots du vocabulaire comptable qui sont aussi des noms de personnes ou de lieux (« Petit », « Blanc »,
# « Clos ») : toujours remplacés, même présents dans le lexique
MOTS_MASQUES = DOSSIER_SKILL / 'references' / 'mots-masques.txt'

# Colonnes conservées telles quelles (comparaison sans tenir compte de la casse)
COLONNES_CONSERVEES = {c.upper() for c in (
    'JournalCode', 'EcritureNum', 'EcritureDate', 'PieceDate', 'Debit', 'Credit', 'Montant', 'Sens', 'EcritureLet', 'DateLet',
    'ValidDate', 'Montantdevise', 'Idevise', 'DateRglt', 'ModeRglt', 'NatOp')}
# Colonne dont seules les lettres sont anonymisées : la racine numérique du compte reste lisible
COLONNE_COMPTE = 'COMPTENUM'

_MOT = re.compile(r'[^\W\d_]+')
_CHIFFRES = re.compile(r'\d{5,}')
# Montant à décimales (« 12345,67 ») : conservé, et jamais pris pour un numéro à rétablir
_FIN_MONTANT = r'(?![.,]\d{1,2}(?!\d))'
_NUMERO = rf'\d{{5,}}(?!\d){_FIN_MONTANT}'
# Téléphone français, y compris « +33 (0)3 88… » et « 0033 3 88… », et numéros internationaux « +41 61… »
_TELEPHONE = re.compile(r'(?<!\d)(?:(?:\+|00)33\s?(?:\(0\)\s?)?|0)[1-9](?:[ .-]?\d{2}){4}(?!\d)'
                        r'|(?<![\w+])\+\d{1,3}(?:[ .-]?\(?\d{1,4}\)?){2,5}(?!\d)')
# IBAN, en majuscules ou en minuscules, groupes séparés par une espace, un point ou un tiret
_IBAN = re.compile(r'\b[A-Za-z]{2}\d{2}(?:[ .-]?[A-Za-z0-9]{4}){3,7}(?:[ .-]?[A-Za-z0-9]{1,3})?\b')
# Numéro écrit par groupes (« 552 100 554 », SIRET, carte, NIR, téléphone étranger) : retenu s'il
# compte au moins 9 chiffres et n'est pas un montant à décimales (« 1 234 567,89 »)
_GROUPES = r'(?<![\d.,])\d{1,4}(?:[ .-]\d{2,4}){2,}(?!\d)' + r'(?![.,]\d{1,2}(?!\d))'
MIN_CHIFFRES_GROUPES = 9
# Pseudonyme d'un mot : code hexadécimal de 7 caractères, comme un identifiant court de commit
# Git (« 3f9a1c2 »). Il contient au moins un chiffre (jamais un mot) et une lettre (jamais un
# nombre), et pas de suite de 5 chiffres (jamais pris pour un numéro à remplacer ou à rétablir).
LONGUEUR_CODE = 7
# Tirages d'un numéro fictif de même longueur avant d'en allonger un d'un chiffre
ESSAIS_MAX = 50


def code_valide(code: str) -> bool:
    return (any(c.isdigit() for c in code) and any(c.isalpha() for c in code)
            and not _CHIFFRES.search(code))
# Version du format de la table de correspondance (1 : mots normalisés et chiffres seuls, sans ligne « format »)
FORMAT_TABLE = '2'
COLONNES_TABLE = ['type', 'original', 'pseudonyme', 'occurrences', 'position']


def normaliser(mot: str) -> str:
    """Minuscules sans accents : « Société » → « societe »."""
    d = unicodedata.normalize('NFD', mot.casefold())
    return ''.join(c for c in d if unicodedata.category(c) != 'Mn')


def _lire_mots(chemin: Path) -> set[str]:
    mots = set()
    if chemin.exists():
        for ligne in chemin.read_text(encoding='utf-8').splitlines():
            ligne = ligne.split('#', 1)[0].strip()
            if ligne:
                mots.update(normaliser(m) for m in _MOT.findall(ligne))
    return mots


def lire_lexique(*chemins: Path) -> set[str]:
    mots = set()
    for chemin in chemins:
        mots |= _lire_mots(chemin)
    return mots - _lire_mots(MOTS_MASQUES)


def construire_lexique(sources: list[str]) -> None:
    """Écrit references/lexique-pcg.txt : les mots des textes donnés (PCG, plan de comptes)."""
    mots = set()
    for s in sources:
        mots.update(normaliser(m) for m in _MOT.findall(Path(s).read_text(encoding='utf-8')) if len(m) >= 2)
    LEXIQUE_PCG.parent.mkdir(parents=True, exist_ok=True)
    entete = f"# Vocabulaire comptable conservé par invisibility-cloak, extrait de : {', '.join(Path(s).name for s in sources)}\n"
    LEXIQUE_PCG.write_text(entete + '\n'.join(sorted(mots)) + '\n', encoding='utf-8', newline='\n')
    print(f'Lexique : {LEXIQUE_PCG} ({len(mots)} mots)')


# --- Lecture et écriture du fichier ----------------------------------------------------

def lire(chemin: str) -> tuple[str, str, bool]:
    """Texte, encodage (nom Python) et présence d'un BOM UTF-8."""
    return decoder(Path(chemin).read_bytes())


def decoder(octets: bytes) -> tuple[str, str, bool]:
    """Texte, encodage (nom Python) et présence d'un BOM UTF-8."""
    if octets.startswith(b'\xef\xbb\xbf'):
        return octets[3:].decode('utf-8', errors='strict'), 'utf-8', True
    try:
        return octets.decode('utf-8'), 'utf-8', False
    except UnicodeDecodeError:
        pass
    # Hors UTF-8, un FEC français est en Windows-1252 (« œ », « € », « — », apostrophe typographique) :
    # pas de détection statistique, qui peut changer d'avis entre le FEC d'origine et le FEC
    # pseudonymisé (cp1250, cp775…) et rendre le rétablissement impossible
    try:
        return octets.decode('cp1252'), 'cp1252', False
    except UnicodeDecodeError:
        return octets.decode('iso-8859-15'), 'iso-8859-15', False


def siren_masque(siren: str) -> str:
    """SIREN du nom du FEC anonymisé : deux premiers et deux derniers chiffres (« 97_____65 »)."""
    return f'{siren[:2]}_____{siren[-2:]}'


def siren_fictif(cle: bytes) -> str:
    """SIREN fictif commençant par 999, avec une clé de Luhn valide."""
    corps = '999' + str(int.from_bytes(hmac.new(cle, b'siren', hashlib.sha256).digest()[:4], 'big') % 100000).zfill(5)
    for d in '0123456789':
        n = corps + d
        total = sum(int(c) * (2 if i % 2 else 1) // 10 + int(c) * (2 if i % 2 else 1) % 10 for i, c in enumerate(n))
        if total % 10 == 0:
            return n
    return corps + '0'


# --- Pseudonymisation ---------------------------------------------------------------

class Cape:
    """Remplace les mots et les numéros d'un FEC par des pseudonymes cohérents."""

    def __init__(self, cle: bytes, lexique: set[str], siren: str, siren_remplacement: str, texte_source: str = ''):
        self.cle = cle
        self.lexique = lexique
        self.siren = siren
        self.siren_remplacement = siren_remplacement
        self.mots: dict[str, str] = {}        # mot normalisé → code (« 3f9a1c2 »)
        # Les pseudonymes évitent tout mot et tout numéro du FEC d'origine : l'anonymat se lève sans ambiguïté
        self.pris: set[str] = {normaliser(m) for m in _MOT.findall(texte_source)}
        self.nombres: dict[str, str] = {}     # chiffres d'origine → chiffres fictifs
        self.chiffres_pris: set[str] = set(re.findall(r'\d{5,}', texte_source))
        self.formes_mots: Counter = Counter()      # (forme d'origine, pseudonyme) → occurrences
        self.formes_nombres: Counter = Counter()   # (numéro d'origine, numéro fictif), mise en forme comprise
        self.compteurs = {'mots': 0, 'nombres': 0}

    def _empreinte(self, prefixe: str, valeur: str, essai: int = 0) -> bytes:
        return hmac.new(self.cle, f'{prefixe}|{essai}|{valeur}'.encode(), hashlib.sha256).digest()

    def pseudonyme(self, mot: str) -> str:
        n = normaliser(mot)
        if n not in self.mots:
            essai = 0
            while True:
                p = self._empreinte('mot', n, essai).hex()[:LONGUEUR_CODE]
                if code_valide(p) and p not in self.pris:
                    break
                essai += 1
            self.mots[n] = p
            self.pris.add(p)
        # Toujours en minuscules, comme un code de commit : la casse d'origine (« ZORBALIX »,
        # « Zorbalix ») est rendue par la table (forme la plus fréquente, champs du FEC en entier)
        return self.mots[n]

    def _tirage(self, nombre: str, essai: int) -> str:
        e = self._empreinte('nombre', nombre, essai)
        return ''.join(str(b % 10) for b in (e * (len(nombre) // len(e) + 1))[:len(nombre)])

    def chiffres(self, nombre: str) -> str:
        """Chiffres fictifs, distincts pour deux numéros distincts (un SIRET garde le SIREN fictif en tête)."""
        if nombre not in self.nombres:
            prefixe, reste = '', nombre
            if self.siren and nombre.startswith(self.siren):
                prefixe, reste = self.siren_remplacement, nombre[len(self.siren):]
            essai = 0
            while True:
                # Au-delà de ESSAIS_MAX, l'espace des numéros de cette longueur est presque épuisé
                # (plus de 50 000 numéros de 5 chiffres distincts) : un chiffre de plus, sinon la
                # boucle ne se termine jamais
                base = reste + '0' * (essai // ESSAIS_MAX)
                r = prefixe + (self._tirage(base, essai) if reste else '')
                if not reste or r not in self.chiffres_pris:
                    break
                essai += 1
            self.nombres[nombre] = r
            self.chiffres_pris.add(r)
        return self.nombres[nombre]

    def amorcer(self, mots: dict, nombres: dict) -> None:
        """Reprend les pseudonymes d'une table existante : mêmes codes, et jamais deux valeurs pour un code."""
        self.mots.update(mots)
        self.pris.update(mots.values())
        self.nombres.update(nombres)
        self.chiffres_pris.update(nombres)
        self.chiffres_pris.update(nombres.values())

    def connu(self, mot: str) -> bool:
        """Mot du lexique, au singulier ou au pluriel (« cartes », « bancaires », « travaux »)."""
        n = normaliser(mot)
        if n in self.lexique:
            return True
        if n.endswith(('s', 'x')) and n[:-1] in self.lexique:
            return True
        return n.endswith('aux') and n[:-3] + 'al' in self.lexique

    def _mot(self, m: re.Match) -> str:
        mot = m.group(0)
        if len(mot) < 2 or self.connu(mot):
            return mot
        self.compteurs['mots'] += 1
        p = self.pseudonyme(mot)
        self.formes_mots[(mot, p)] += 1
        return p

    def _numero(self, m: re.Match) -> str:
        """Remplace les chiffres d'un numéro (SIREN, IBAN, téléphone, suite de chiffres) en gardant sa mise en forme."""
        brut = m.group(0)
        if m.lastgroup == 'groupes' and len(re.sub(r'\D', '', brut)) < MIN_CHIFFRES_GROUPES:
            # Trop court pour un identifiant (date, petit montant) : seuls ses numéros de 5 chiffres et plus
            return re.sub(_NUMERO, self._numero, brut)
        self.compteurs['nombres'] += 1
        if m.lastgroup == 'siren':
            r = self.siren_remplacement
        else:
            nouveaux = iter(self.chiffres(re.sub(r'\D', '', brut)))
            r = re.sub(r'\d', lambda _: next(nouveaux), brut)
        self.formes_nombres[(brut, r)] += 1
        return r

    def texte(self, valeur: str) -> str:
        if not valeur:
            return valeur
        # Un seul passage pour les numéros : un numéro déjà remplacé n'est pas remplacé une seconde fois.
        # Les lettres d'un numéro (IBAN « FR76 », « GB29 NWBK ») ne sont pas traitées comme des mots :
        # sinon leur casse change au rétablissement et l'IBAN fictif n'est plus reconnu.
        morceaux, debut = [], 0
        for m in self.numeros.finditer(valeur):
            morceaux.append(_MOT.sub(self._mot, valeur[debut:m.start()]))
            morceaux.append(self._numero(m))
            debut = m.end()
        morceaux.append(_MOT.sub(self._mot, valeur[debut:]))
        return ''.join(morceaux)

    @property
    def numeros(self) -> re.Pattern:
        if not hasattr(self, '_numeros'):
            motifs = []
            if self.siren:
                motifs.append(r'(?P<siren>(?<!\d)' + r'\s?'.join(self.siren) + r'(?![\d]))')
            motifs += [f'(?P<iban>{_IBAN.pattern})', f'(?P<telephone>{_TELEPHONE.pattern})',
                       f'(?P<groupes>{_GROUPES})', f'(?P<chiffres>{_NUMERO})']
            self._numeros = re.compile('|'.join(motifs))
        return self._numeros

    def compte(self, valeur: str) -> str:
        """Numéro de compte : la partie numérique reste, les lettres (compte auxiliaire nominatif) sont anonymisées."""
        return _MOT.sub(self._mot, valeur)


# --- Table de correspondance et levée de l'anonymat (reprises par remove-cloak) -----------

def empreinte(octets: bytes) -> str:
    return hashlib.sha256(octets).hexdigest()


def table_en_texte(table: dict) -> str:
    """Table CSV (« ; »), une ligne par correspondance."""
    f = io.StringIO(newline='')
    w = csv.writer(f, delimiter=';')
    w.writerow(COLONNES_TABLE)
    w.writerow(['format', FORMAT_TABLE, '', '', ''])
    for genre in ('fichier', 'empreinte', 'siren'):
        if table.get(genre):
            w.writerow([genre, *table[genre], '', ''])
    w.writerows(['mot', o, p, n, ''] for o, p, n in table['mots'])
    w.writerows(['nombre', o, p, n, ''] for o, p, n in table['nombres'])
    w.writerows(['champ', o, a, '', pos] for pos, (o, a) in table['champs'].items())
    return f.getvalue()


def texte_en_table(texte: str) -> dict:
    """Lit une table de correspondance (format 2, ou format 1 des premières versions)."""
    table = {'format': '1', 'fichier': None, 'empreinte': None, 'siren': None, 'mots': [], 'nombres': [], 'champs': {}}
    for ligne in csv.reader(io.StringIO(texte, newline=''), delimiter=';'):
        if not ligne or ligne[0] == 'type':
            continue
        genre, original, pseudo, occurrences, position = (ligne + [''] * 5)[:5]
        n = int(occurrences) if occurrences.isdigit() else 1
        if genre == 'format':
            table['format'] = original
        elif genre in ('fichier', 'empreinte', 'siren'):
            table[genre] = (original, pseudo)
        elif genre == 'mot':
            table['mots'].append((original, pseudo, n))
        elif genre == 'nombre':
            table['nombres'].append((original, pseudo, n))
        elif genre == 'champ':
            table['champs'][position] = (original, pseudo)
    return table


def ecrire_table(chemin: str, table: dict) -> None:
    """Écrit la table en clair (UTF-8 avec BOM pour Excel)."""
    with open(chemin, 'w', encoding='utf-8-sig', newline='') as f:
        f.write(table_en_texte(table))


def lire_table(chemin: str) -> dict:
    with open(chemin, encoding='utf-8-sig', newline='') as f:
        return texte_en_table(f.read())


def _casse(modele: str, mot: str) -> str:
    """Donne à « mot » la casse de « modele » : majuscules, initiale ou minuscules."""
    if modele.isupper() and len(modele) > 1:
        return mot.upper()
    if modele[:1].isupper():
        return mot[:1].upper() + mot[1:].lower()
    return mot.lower()


class Restauration:
    """Remplace les pseudonymes d'un texte par les mots et les numéros d'origine, d'après la table.

    Un pseudonyme issu de plusieurs graphies d'origine reçoit la plus fréquente ; un pseudonyme
    dont la casse a changé (mis en majuscules par un contrôle) est retrouvé sans tenir compte de
    la casse, et le mot d'origine prend sa casse.
    """

    def __init__(self, table: dict):
        exact, sans_casse, nombres = defaultdict(Counter), defaultdict(Counter), defaultdict(Counter)
        for o, p, n in table['mots']:
            exact[p][o] += n
            sans_casse[p.casefold()][o] += n
        for o, p, n in table['nombres']:
            nombres[p][o] += n
        self.siren_masque = None
        if table.get('siren'):
            o, p = table['siren']
            nombres[p][o] += 0
            self.siren_masque = (siren_masque(o), o)
        self.mots = {p: c.most_common(1)[0][0] for p, c in exact.items()}
        self.mots_casse = {p: c.most_common(1)[0][0] for p, c in sans_casse.items()}
        self.nombres = {p: c.most_common(1)[0][0] for p, c in nombres.items()}
        self.champs = table.get('champs', {})
        # Codes hexadécimaux (« 3f9a1c2 ») : ils mêlent chiffres et lettres, _MOT ne les voit pas en
        # entier. Ils peuvent toucher des chiffres (« 4013f9a1c2 », compte 401 + code), jamais une lettre.
        # Les pseudonymes de syllabes des tables plus anciennes restent rétablis par _MOT.
        codes = sorted(p for p in self.mots_casse if not p.isalpha())
        self._codes = None
        if codes:
            alternatives = '|'.join(re.escape(p) for p in codes)
            self._codes = re.compile(rf'(?<![^\W\d_])(?:{alternatives})(?![^\W\d_])', re.IGNORECASE)
        self._numeros = None
        if self.nombres:
            # Ni au milieu d'un nombre plus long, ni dans un montant (« 12345,67 », « 12345.67 »)
            alternatives = '|'.join(re.escape(p) for p in sorted(self.nombres, key=len, reverse=True))
            self._numeros = re.compile(rf'(?<!\d)(?:{alternatives})(?!\d){_FIN_MONTANT}')

    def _mot(self, m: re.Match) -> str:
        t = m.group(0)
        if t in self.mots:
            return self.mots[t]
        o = self.mots_casse.get(t.casefold())
        return t if o is None else _casse(t, o)

    def _mots(self, valeur: str) -> str:
        if self._codes:
            valeur = self._codes.sub(self._mot, valeur)
        return _MOT.sub(self._mot, valeur)

    def compte(self, valeur: str) -> str:
        return self._mots(valeur) if valeur else valeur

    def texte(self, valeur: str) -> str:
        if not valeur:
            return valeur
        # SIREN masqué du nom du FEC anonymisé (« 97_____65 »), repris par les résultats de contrôle
        if self.siren_masque:
            valeur = valeur.replace(*self.siren_masque)
        # Ordre inverse de l'anonymisation : les mots, puis les numéros (un IBAN garde ses lettres d'origine dans la table)
        valeur = self._mots(valeur)
        if self._numeros:
            valeur = self._numeros.sub(lambda m: self.nombres[m.group(0)], valeur)
        return valeur

    def champ(self, ligne: int, colonne: int, nom: str, valeur: str) -> str:
        """Valeur d'origine d'un champ du FEC anonymisé (ligne et colonne comptées à partir de 1)."""
        enregistre = self.champs.get(f'{ligne}:{colonne}')
        if enregistre and enregistre[1] == valeur:
            return enregistre[0]
        return self.compte(valeur) if nom == COLONNE_COMPTE else self.texte(valeur)


# --- Traitement d'un FEC en mémoire ---------------------------------------------------------

class ErreurFec(Exception):
    """FEC inexploitable. Le message ne contient aucune donnée du fichier."""


def _structure(texte: str) -> tuple[str, list[str], str, list[str]]:
    """Fin de ligne, lignes, séparateur et colonnes (en majuscules) d'un FEC."""
    fin_ligne = '\r\n' if '\r\n' in texte else '\n'
    lignes = re.split(r'\r?\n', texte)
    entete = lignes[0].lstrip('\ufeff')
    if '\t' in entete:
        sep = '\t'
    elif '|' in entete:
        sep = '|'
    else:
        raise ErreurFec("séparateur introuvable dans la ligne d'en-tête (tabulation ou barre verticale attendue).")
    return fin_ligne, lignes, sep, [c.strip().upper() for c in entete.split(sep)]


def _encoder(lignes: list[str], fin_ligne: str, encodage: str, bom: bool) -> bytes:
    return (('\ufeff' if bom else '') + fin_ligne.join(lignes)).encode(encodage, errors='strict')


def pseudonymiser_fec(source: Path, cle: bytes, siren_impose: str = '', garder=(), connus: dict | None = None) -> dict:
    """Pseudonymise un FEC en mémoire : rien n'est écrit, la garde de la table revient à l'appelant.

    `connus` (facultatif) : correspondances déjà attribuées par la même table, {'mots': {mot normalisé:
    code}, 'nombres': {chiffres: chiffres fictifs}} : elles sont reprises, et aucun nouveau
    pseudonyme ne peut les reprendre pour une autre valeur.
    """
    octets = source.read_bytes()
    texte, encodage, bom = decoder(octets)
    fin_ligne, lignes, sep, colonnes = _structure(texte)

    m = re.search(r'(\d{9})FEC(\d{8})', source.name, re.IGNORECASE)
    siren = m.group(1) if m else ''
    remplacement = siren_impose or siren_fictif(cle)

    lexique = lire_lexique(LEXIQUE_PCG, MOTS_CONSERVES, MOTS_LOCAUX)
    lexique.update(normaliser(mot) for mot in garder)
    if not lexique:
        print(f'Attention : lexique vide ({LEXIQUE_PCG}) : tous les mots seront remplacés.', file=sys.stderr)
    cape = Cape(cle, lexique, siren, remplacement, texte)
    if connus:
        cape.amorcer(connus.get('mots', {}), connus.get('nombres', {}))

    sortie_lignes = [lignes[0]]
    for ligne in lignes[1:]:
        if ligne.strip() == '':
            sortie_lignes.append(ligne)
            continue
        champs = ligne.split(sep)
        for i, valeur in enumerate(champs):
            nom = colonnes[i] if i < len(colonnes) else ''
            if nom in COLONNES_CONSERVEES:
                continue
            champs[i] = cape.compte(valeur) if nom == COLONNE_COMPTE else cape.texte(valeur)
        sortie_lignes.append(sep.join(champs))
    sortie = _encoder(sortie_lignes, fin_ligne, encodage, bom)

    # Vérification : même nombre de lignes et de champs, montants et comptes numériques intacts
    relu = re.split(r'\r?\n', decoder(sortie)[0])
    assert len(relu) == len(lignes), 'nombre de lignes modifié'
    for a, b in zip(lignes, relu):
        assert len(a.split(sep)) == len(b.split(sep)), 'nombre de champs modifié'

    nom_sortie = f'{siren_masque(siren)}FEC{m.group(2)}.txt' if m else f'{source.stem}-anonyme{source.suffix}'
    table = {
        'fichier': (source.name, nom_sortie),
        'empreinte': (empreinte(octets), empreinte(sortie)),
        'siren': (siren, remplacement) if siren else None,
        'mots': [(o, p, n) for (o, p), n in sorted(cape.formes_mots.items())],
        'nombres': [(o, p, n) for (o, p), n in sorted(cape.formes_nombres.items())],
        'champs': {},
    }
    # Les champs que les mots et les numéros ne suffisent pas à rétablir sont enregistrés en entier
    restauration = Restauration(table)
    for n, (avant, apres) in enumerate(zip(lignes, sortie_lignes)):
        if n == 0 or avant.strip() == '':
            continue
        for i, (a, b) in enumerate(zip(avant.split(sep), apres.split(sep))):
            nom = colonnes[i] if i < len(colonnes) else ''
            if nom not in COLONNES_CONSERVEES and restauration.champ(n + 1, i + 1, nom, b) != a:
                table['champs'][f'{n + 1}:{i + 1}'] = (a, b)
    return {'nom': nom_sortie, 'octets': sortie, 'table': table, 'siren': siren, 'remplacement': remplacement,
            'lignes': len(lignes) - 1, 'cape': cape}


def retablir_fec(octets: bytes, table: dict) -> bytes:
    """FEC d'origine, à partir du FEC anonymisé et de sa table."""
    texte, encodage, bom = decoder(octets)
    fin_ligne, lignes, sep, colonnes = _structure(texte)
    restauration = Restauration(table)
    sortie_lignes = [lignes[0]]
    for n, ligne in enumerate(lignes[1:], start=2):
        if ligne.strip() == '':
            sortie_lignes.append(ligne)
            continue
        champs = ligne.split(sep)
        for i, valeur in enumerate(champs):
            nom = colonnes[i] if i < len(colonnes) else ''
            if nom not in COLONNES_CONSERVEES:
                champs[i] = restauration.champ(n, i + 1, nom, valeur)
        sortie_lignes.append(sep.join(champs))
    resultat = _encoder(sortie_lignes, fin_ligne, encodage, bom)
    # Un FEC anonymisé peut ne plus contenir aucun accent et se lire en UTF-8, quel que soit
    # l'encodage d'origine : l'empreinte de la table permet de le retrouver
    if table.get('empreinte') and empreinte(resultat) != table['empreinte'][0]:
        for autre in ('iso-8859-15', 'cp1252'):
            try:
                essai = _encoder(sortie_lignes, fin_ligne, autre, False)
            except UnicodeEncodeError:
                continue
            if empreinte(essai) == table['empreinte'][0]:
                return essai
    return resultat


# --- Programme principal ------------------------------------------------------------------

def anonymiser(args) -> int:
    source = Path(args.fec)
    if not source.is_file():
        print(f'Erreur : fichier introuvable : {source}', file=sys.stderr)
        return 1
    if args.siren and not re.fullmatch(r'\d{9}', args.siren):
        print('Erreur : --siren attend 9 chiffres.', file=sys.stderr)
        return 1
    cle = args.cle.encode() if args.cle else secrets.token_bytes(32)
    try:
        resultat = pseudonymiser_fec(source, cle, args.siren or '', args.garder or ())
    except ErreurFec as e:
        print(f'Erreur : {e}', file=sys.stderr)
        return 1
    siren, cape = resultat['siren'], resultat['cape']

    dossier = Path(args.sortie) if args.sortie else source.parent
    dossier.mkdir(parents=True, exist_ok=True)
    cible = dossier / resultat['nom']
    m = re.search(r'(\d{9})FEC(\d{8})', source.name, re.IGNORECASE)
    # La table de correspondance est toujours écrite, à côté du FEC anonymisé sauf --correspondance
    chemin_table = Path(args.correspondance) if args.correspondance else \
        dossier / (f'{siren}FEC{m.group(2)}-cloak-table.csv' if m else f'{source.stem}-cloak-table.csv')
    if cible.resolve() == source.resolve():
        print('Erreur : le fichier anonymisé remplacerait le FEC d\'origine ; choisir un autre dossier avec --sortie.', file=sys.stderr)
        return 1
    for fichier in (cible, chemin_table):
        if fichier.exists() and not args.remplacer:
            print(f'Erreur : {fichier} existe déjà ; ajouter --remplacer pour l\'écraser.', file=sys.stderr)
            return 1
    cible.write_bytes(resultat['octets'])
    chemin_table.parent.mkdir(parents=True, exist_ok=True)
    ecrire_table(str(chemin_table), resultat['table'])

    print(f'FEC anonymisé : {cible}')
    # SIREN masqué : la sortie de la console peut être lue par Claude
    print(f"SIREN {siren_masque(siren) if siren else '(absent du nom)'} → {resultat['remplacement']} · {resultat['lignes']} ligne(s) · "
          f"{len(cape.mots)} mot(s) distinct(s) remplacé(s) ({cape.compteurs['mots']} occurrence(s)) · "
          f"{len(cape.nombres)} numéro(s) distinct(s) remplacé(s)")
    print(f"Table de correspondance : {chemin_table} (confidentielle : elle permet de lever l'anonymat ; "
          f"{len(resultat['table']['champs'])} champ(s) enregistré(s) en entier)")
    return 0


def main(argv=None) -> int:
    for flux in (sys.stdout, sys.stderr):
        flux.reconfigure(encoding='utf-8')
    p = argparse.ArgumentParser(description="Outil d'anonymisation des FEC (Cape d'invisibilité).")
    p.add_argument('--fec', help='FEC à anonymiser (.txt)')
    p.add_argument('--sortie', help='dossier du FEC anonymisé (défaut : dossier du FEC)')
    p.add_argument('--siren', help='SIREN fictif à utiliser (défaut : 999xxxxxx tiré de la clé)')
    p.add_argument('--cle', help="phrase secrète : avec la même clé, un même mot reçoit le même pseudonyme d'un FEC à l'autre (défaut : clé aléatoire)")
    p.add_argument('--garder', nargs='*', help='mots à conserver en plus du lexique')
    p.add_argument('--correspondance', help='chemin de la table original → pseudonyme, toujours écrite (défaut : <SIREN>FEC<clôture>-cloak-table.csv à côté du FEC anonymisé ; confidentielle)')
    p.add_argument('--remplacer', action='store_true', help='écraser le FEC anonymisé et la table s\'ils existent déjà')
    p.add_argument('--construire-lexique', nargs='+', metavar='TEXTE', help='reconstruit references/lexique-pcg.txt à partir de ces textes')
    args = p.parse_args(argv)
    if args.construire_lexique:
        construire_lexique(args.construire_lexique)
        return 0
    if not args.fec:
        p.error('--fec est obligatoire')
    return anonymiser(args)


if __name__ == '__main__':
    sys.exit(main())
