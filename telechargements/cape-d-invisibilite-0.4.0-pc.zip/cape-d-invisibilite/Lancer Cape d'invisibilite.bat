@echo off
rem Demarre la page web locale et ouvre le navigateur. Equivalent Mac : Lancer Cape d'invisibilite.command
rem Fermer cette fenetre arrete l'application.
chcp 65001 >nul
cd /d "%~dp0"

rem Banniere ASCII (packaging\banniere.ascii), en bleu sauf si NO_COLOR est defini.
if not exist "packaging\banniere.ascii" goto :apres_banniere
if defined NO_COLOR goto :banniere_sans_couleur
for /f %%e in ('echo prompt $E^| cmd') do set "ESC=%%e"
<nul set /p "=%ESC%[1;38;5;27m"
type "packaging\banniere.ascii"
<nul set /p "=%ESC%[0m"
goto :apres_banniere
:banniere_sans_couleur
type "packaging\banniere.ascii"
:apres_banniere

if not exist ".venv\Scripts\python.exe" (
    echo Cape d'invisibilite n'est pas installe. Lancez d'abord installer.bat.
    pause
    exit /b 1
)

.venv\Scripts\python -m invisibility_cloak.app.web
if errorlevel 1 pause
