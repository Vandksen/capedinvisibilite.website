"""Classeurs Excel (.xlsx) via openpyxl.

Sont transformés : cellules texte, textes entre guillemets des formules, noms d'onglets (les
références sont mises à jour), colonnes de tableaux, commentaires, en-têtes et pieds de page,
liens, validations de données, mises en forme conditionnelles, propriétés du classeur.
Les nombres sont conservés : ce sont les montants à analyser.

Noms définis et noms de tableaux : renommés « Nom1 », « Tableau1 »… (leur syntaxe interdit un
code commençant par un chiffre), formules mises à jour. Tableaux croisés dynamiques et liaisons
vers d'autres classeurs : retirés (leur cache garde les données d'origine en clair) ; les valeurs
affichées par un tableau croisé restent, pseudonymisées, dans les cellules.
Nombres d'une colonne d'identifiants (SIREN, SIRET, téléphone, IBAN, NIR, n°…) : pseudonymisés.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from invisibility_cloak.formats.base import DEFAULT_OPTIONS, Options, TextTransform, transform_url

_MAX_TITLE_LENGTH = 31
_STRUCTURED_COLUMN = re.compile(r"\[(?!#)([^\[\]]+)\]")
_PROPERTIES = ("title", "subject", "description", "keywords", "category")
# En-tête d'une colonne dont les nombres sont des identifiants, pas des montants
_IDENTIFIER_HEADER = re.compile(
    r"siren|siret|tva|iban|rib|bic|t[ée]l|phone|mobile|portable|fax|nir|s[ée]cu|n°|num[ée]ro|"
    r"\bno\b|\bnum\b|matricule|carte|compte bancaire|identifiant",
    re.IGNORECASE,
)
_HEADER_ROWS = 5
_MIN_IDENTIFIER_DIGITS = 5


class _Rewriter:
    """Applique la transformation aux formules, en suivant les onglets renommés."""

    def __init__(self, transform: TextTransform, titles: dict[str, str]) -> None:
        self.transform = transform
        self.titles = titles
        # Noms définis et noms de tableaux renommés (ancien nom en minuscules → nouveau nom)
        self.identifiers: dict[str, str] = {}

    def _identifier(self, value: str) -> str:
        if not self.identifiers:
            return value
        name, bracket, rest = value.partition("[")
        new = self.identifiers.get(name.casefold())
        return value if new is None else new + bracket + rest

    def reference(self, value: str) -> str:
        """Référence d'une formule : onglet renommé, colonne d'un tableau structuré."""
        if "!" in value:
            sheet, cell = value.rsplit("!", 1)
            names = sheet.removeprefix("'").removesuffix("'").replace("''", "'").split(":")
            if any(name in self.titles for name in names):
                renamed = ":".join(self.titles.get(name, name) for name in names)
                value = "'" + renamed.replace("'", "''") + "'!" + cell
        value = self._identifier(value)
        return _STRUCTURED_COLUMN.sub(lambda m: f"[{self.transform(m.group(1))}]", value)

    def _literal(self, value: str) -> str:
        text = value[1:-1].replace('""', '"')
        return '"' + self.transform(text).replace('"', '""') + '"'

    def formula(self, formula: str) -> str:
        """Formule commençant par « = » : seuls ses textes et ses références changent."""
        from openpyxl.formula import Tokenizer
        from openpyxl.formula.tokenizer import Token

        parts: list[str] = []
        functions: list[str] = []
        previous: Any = None
        for token in Tokenizer(formula).items:
            value = token.value
            if token.subtype == Token.OPEN:
                functions.append(value.upper())
            elif token.subtype == Token.CLOSE and functions:
                functions.pop()
            if token.type == Token.OPERAND and token.subtype == Token.TEXT:
                # Le format de TEXTE(valeur;"jj/mm/aaaa") est une syntaxe, pas une donnée
                is_format = (
                    functions[-1:] == ["TEXT("]
                    and previous is not None
                    and previous.type == Token.SEP
                )
                value = value if is_format else self._literal(value)
            elif token.type == Token.OPERAND and token.subtype == Token.RANGE:
                value = self.reference(value)
            parts.append(value)
            if token.type != Token.WSPACE:
                previous = token
        return "=" + "".join(parts)

    def expression(self, expression: str) -> str:
        """Formule stockée sans « = » (nom défini, validation, mise en forme conditionnelle)."""
        return self.formula(f"={expression}")[1:]


def _fit_title(title: str, taken: set[str]) -> str:
    """Nom d'onglet accepté par Excel : 31 caractères au plus, sans doublon."""
    candidate = title[:_MAX_TITLE_LENGTH]
    index = 0
    while candidate.casefold() in taken:
        index += 1
        suffix = str(index)
        candidate = title[: _MAX_TITLE_LENGTH - len(suffix)] + suffix
    taken.add(candidate.casefold())
    return candidate


def _rename_sheets(workbook: Any, transform: TextTransform) -> dict[str, str]:
    """Renomme les onglets ; renvoie les changements (ancien nom → nouveau nom)."""
    titles: dict[str, str] = {}
    taken: set[str] = set()
    for sheet in [*workbook.worksheets, *workbook.chartsheets]:
        old = sheet.title
        new = _fit_title(transform(old), taken)
        if new != old:
            sheet.title = new
            titles[old] = sheet.title
    return titles


def _transform_cell(cell: Any, transform: TextTransform, rewriter: _Rewriter) -> None:
    from openpyxl.worksheet.formula import ArrayFormula

    value = cell.value
    if isinstance(value, ArrayFormula):
        if value.text:
            value.text = rewriter.formula(value.text)
    elif cell.data_type == "f" and isinstance(value, str):
        cell.value = rewriter.formula(value)
    elif isinstance(value, str) and value.strip():
        cell.value = transform(value)
    if cell.comment is not None:
        cell.comment.text = transform(cell.comment.text)
        cell.comment.author = transform(cell.comment.author or "")
    link = cell.hyperlink
    if link is not None:
        if link.target:
            link.target = transform_url(link.target, transform)
        if link.location:
            link.location = rewriter.reference(link.location)
        if link.tooltip:
            link.tooltip = transform(link.tooltip)
        if link.display:
            link.display = transform(link.display)


def _transform_headers(sheet: Any, transform: TextTransform) -> None:
    for name in (
        "oddHeader",
        "oddFooter",
        "evenHeader",
        "evenFooter",
        "firstHeader",
        "firstFooter",
    ):
        block = getattr(sheet, name)
        for part in (block.left, block.center, block.right):
            if part.text:
                part.text = transform(part.text)


def _transform_filters(filters: Iterable[Any], transform: TextTransform) -> None:
    for auto_filter in filters:
        for column in auto_filter.filterColumn:
            if column.filters is not None:
                column.filters.filter = [transform(value) for value in column.filters.filter]


def _transform_tables(sheet: Any, transform: TextTransform) -> None:
    """Colonnes des tableaux : Excel exige qu'elles restent identiques aux cellules d'en-tête."""
    for table in sheet.tables.values():
        for column in table.tableColumns:
            column.name = transform(column.name)
            if column.totalsRowLabel:
                column.totalsRowLabel = transform(column.totalsRowLabel)
    _transform_filters(
        [sheet.auto_filter, *(t.autoFilter for t in sheet.tables.values() if t.autoFilter)],
        transform,
    )


def _transform_rules(sheet: Any, transform: TextTransform, rewriter: _Rewriter) -> None:
    for validation in sheet.data_validations.dataValidation:
        for name in ("prompt", "promptTitle", "error", "errorTitle"):
            if getattr(validation, name):
                setattr(validation, name, transform(getattr(validation, name)))
        for name in ("formula1", "formula2"):
            if getattr(validation, name):
                setattr(validation, name, rewriter.expression(getattr(validation, name)))
    for formatting in sheet.conditional_formatting:
        for rule in formatting.rules:
            rule.formula = [rewriter.expression(formula) for formula in rule.formula]
            if rule.text:
                rule.text = transform(rule.text)


def _transform_names(names: Any, rewriter: _Rewriter) -> None:
    for name in names.values():
        if name.attr_text:
            name.attr_text = rewriter.expression(name.attr_text)


def _rename_identifiers(workbook: Any, rewriter: _Rewriter) -> None:
    """Noms définis et noms de tableaux → « Nom1 », « Tableau1 » : ils citent souvent un client."""
    scopes = [workbook.defined_names, *(ws.defined_names for ws in workbook.worksheets)]
    index = 0
    for names in scopes:
        for old in list(names):
            if old.startswith("_xlnm."):  # zone d'impression, filtres : noms réservés
                continue
            index += 1
            new = f"Nom{index}"
            defined = names.pop(old)
            defined.name = new
            names[new] = defined
            rewriter.identifiers[old.casefold()] = new
    index = 0
    for ws in workbook.worksheets:
        for table in list(ws.tables.values()):
            index += 1
            old = table.displayName
            new = f"Tableau{index}"
            del ws.tables[old]
            table.displayName = table.name = new
            ws.tables[new] = table
            rewriter.identifiers[old.casefold()] = new


def _drop_caches(workbook: Any) -> None:
    """Tableaux croisés et liaisons externes : leurs caches gardent les valeurs d'origine."""
    for ws in workbook.worksheets:
        ws._pivots = []
    workbook._external_links = []


def _identifier_columns(sheet: Any) -> set[int]:
    columns: set[int] = set()
    for row in sheet.iter_rows(max_row=_HEADER_ROWS):
        for cell in row:
            if isinstance(cell.value, str) and _IDENTIFIER_HEADER.search(cell.value):
                columns.add(cell.column)
    return columns


def _transform_number(cell: Any, transform: TextTransform) -> None:
    """Nombre entier d'une colonne d'identifiants (SIREN, téléphone…) : chiffres fictifs."""
    value = cell.value
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value != int(value):
        return
    digits = str(int(abs(value)))
    if len(digits) < _MIN_IDENTIFIER_DIGITS:
        return
    fictive = transform(digits)
    # Un numéro fictif qui commence par 0 reste un texte, pour garder tous ses chiffres
    cell.value = int(fictive) if not fictive.startswith("0") else fictive


def _transform_properties(workbook: Any, transform: TextTransform) -> None:
    properties = workbook.properties
    for name in _PROPERTIES:
        if getattr(properties, name):
            setattr(properties, name, transform(getattr(properties, name)))
    properties.creator = ""
    properties.lastModifiedBy = ""
    for custom in workbook.custom_doc_props.props:
        if isinstance(custom.value, str) and custom.value:
            custom.value = transform(custom.value)


def _freeze_values(workbook: Any, source: Path) -> None:
    """Remplace chaque formule par son dernier résultat enregistré par Excel (M9).

    openpyxl réécrit les formules sans leur résultat : une IA qui lit le classeur sans le
    recalculer voit des totaux vides. Une formule jamais calculée (pas de résultat en cache)
    reste une formule. Un résultat texte est ensuite pseudonymisé comme toute cellule.
    """
    import openpyxl
    from openpyxl.worksheet.formula import ArrayFormula

    values = openpyxl.load_workbook(str(source), data_only=True)
    for sheet, cached in zip(workbook.worksheets, values.worksheets, strict=True):
        for row in sheet.iter_rows():
            for cell in row:
                if not (isinstance(cell.value, ArrayFormula) or cell.data_type == "f"):
                    continue
                value = cached[cell.coordinate].value
                if value is None:
                    continue
                cell.value = value
                if isinstance(value, str):
                    # Un résultat qui commence par « = » reste un texte
                    cell.data_type = "s"
    values.close()


class XlsxHandler:
    def transform(
        self,
        source: Path,
        target: Path,
        transform: TextTransform,
        options: Options = DEFAULT_OPTIONS,
    ) -> None:
        import openpyxl

        workbook = openpyxl.load_workbook(str(source))
        if options.freeze_values:
            _freeze_values(workbook, source)
        _drop_caches(workbook)
        rewriter = _Rewriter(transform, _rename_sheets(workbook, transform))
        _rename_identifiers(workbook, rewriter)
        _transform_names(workbook.defined_names, rewriter)
        for sheet in workbook.worksheets:
            identifiers = _identifier_columns(sheet)
            for row in sheet.iter_rows():
                for cell in row:
                    if cell.column in identifiers and cell.data_type == "n":
                        _transform_number(cell, transform)
                        if isinstance(cell.value, str):
                            # Déjà pseudonymisé (« 0235… ») : ne pas le transformer une seconde fois
                            cell.data_type = "s"
                            continue
                    _transform_cell(cell, transform, rewriter)
            _transform_headers(sheet, transform)
            _transform_tables(sheet, transform)
            _transform_rules(sheet, transform, rewriter)
            _transform_names(sheet.defined_names, rewriter)
        _transform_properties(workbook, transform)
        workbook.save(str(target))


HANDLER = XlsxHandler()
