"""Interface commune aux gestionnaires de formats."""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

TextTransform = Callable[[str], str]

_URL_SCHEME = re.compile(r"[A-Za-z][A-Za-z0-9+.-]*:(?://)?")


def transform_url(url: str, transform: TextTransform) -> str:
    """Transforme une adresse en gardant son protocole : sans lui, le lien serait invalide."""
    match = _URL_SCHEME.match(url)
    scheme = match.group(0) if match else ""
    return scheme + transform(url[len(scheme) :])


@dataclass(frozen=True)
class Options:
    """Choix de l'utilisateur pour la pseudonymisation (cases de la page locale)."""

    # Excel : chaque formule devient son dernier résultat, que l'IA lit sans recalcul (M9)
    freeze_values: bool = False
    # Word : les images sont retirées ; un nom visible dans une image n'est pas masqué (M10)
    drop_images: bool = False


DEFAULT_OPTIONS = Options()


class FormatHandler(Protocol):
    """Lit un fichier, applique `transform` à chaque fragment de texte, réécrit le fichier."""

    def transform(
        self,
        source: Path,
        target: Path,
        transform: TextTransform,
        options: Options = DEFAULT_OPTIONS,
    ) -> None: ...
