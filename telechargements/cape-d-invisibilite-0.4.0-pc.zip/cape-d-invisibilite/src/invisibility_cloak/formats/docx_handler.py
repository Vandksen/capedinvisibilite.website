"""Documents Word (.docx) via python-docx.

Tout le texte est transformé : corps, tableaux, zones de texte, en-têtes, pieds de page, notes,
commentaires, révisions, liens, textes de remplacement des images et propriétés du document.
Un nom pouvant être éclaté sur plusieurs « runs », le texte est traité par suite de runs
contiguës, réunie dans la première : une mise en forme partielle à l'intérieur de cette suite
est perdue. Tabulations, sauts de ligne, images et liens séparent ces suites et restent en place.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from invisibility_cloak.formats.base import DEFAULT_OPTIONS, Options, TextTransform, transform_url

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_W15 = "{http://schemas.microsoft.com/office/word/2012/wordml}"
_XML_SPACE = "{http://www.w3.org/XML/1998/namespace}space"
_TEXT_TAGS = {f"{_W}t", f"{_W}delText"}
_TEXT_PARTS = re.compile(
    r"/word/(glossary/)?"
    r"(document|header\d*|footer\d*|footnotes|endnotes|comments|people)\.xml"
)
# Auteurs des révisions et commentaires ; textes de remplacement des images et formes
_TEXT_ATTRIBUTES = {
    f"{_W}author",
    f"{_W}initials",
    f"{_W15}author",
    f"{_W15}userId",
    "descr",
    "title",
    "alt",
}
_PROPERTY_PARTS = {"/docProps/app.xml", "/docProps/custom.xml"}
_PROPERTY_TAGS = {"Company", "Manager", "HyperlinkBase", "lpwstr"}
_CORE_PROPERTIES = ("title", "subject", "comments", "keywords", "category")
_CORE_PROPERTY_MAX_LENGTH = 255
_HYPERLINK_RELATIONSHIP = "/hyperlink"
_A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
_C = "{http://schemas.openxmlformats.org/drawingml/2006/chart}"
# Graphiques et SmartArt : leurs libellés en cache (séries, catégories, textes) sont en clair
_DRAWING_PARTS = re.compile(r"/word/(charts/chart\d+|diagrams/(data|drawing)\d+)\.xml")
# Libellés seulement : les valeurs numériques en cache (numCache) sont les montants du graphique
_SETTINGS_PART = "/word/settings.xml"
_ATTACHED_TEMPLATE_RELATIONSHIP = "/attachedTemplate"
# Classeurs et documents incorporés (graphiques, objets OLE) : pseudonymisés à leur tour
_EMBEDDED_PART = re.compile(
    r"/word/(embeddings|charts/embeddings)/[^/]+\.(xlsx|docx)", re.IGNORECASE
)
_THUMBNAIL_RELATIONSHIP = "/thumbnail"
# Images retirées sur demande (M10) : dessins qui portent une image, images VML anciennes
_PIC = "{http://schemas.openxmlformats.org/drawingml/2006/picture}pic"
_V_IMAGEDATA = "{urn:schemas-microsoft-com:vml}imagedata"
_V_TEXTBOX = "{urn:schemas-microsoft-com:vml}textbox"
_IMAGE_RELATIONSHIP = "/image"
IMAGE_PLACEHOLDER = "[image retirée]"


def _segments(paragraph: Any) -> list[list[Any]]:
    """Éléments de texte du paragraphe, regroupés par suite de runs contiguës."""
    segments: list[list[Any]] = []
    current: list[Any] = []
    previous_parent = None
    for run in paragraph.iter(f"{_W}r"):
        # Une zone de texte contient ses propres paragraphes, traités à part
        if next(run.iterancestors(f"{_W}p"), None) is not paragraph:
            continue
        if run.getparent() is not previous_parent:
            current = []
            segments.append(current)
            previous_parent = run.getparent()
        for child in run:
            if child.tag in _TEXT_TAGS:
                current.append(child)
            elif child.tag != f"{_W}rPr":
                current = []
                segments.append(current)
    return segments


def _transform_paragraph(paragraph: Any, transform: TextTransform) -> None:
    for elements in _segments(paragraph):
        text = "".join(element.text or "" for element in elements)
        if not text.strip():
            continue
        new_text = transform(text)
        if new_text != text:
            elements[0].text = new_text
            elements[0].set(_XML_SPACE, "preserve")
            for element in elements[1:]:
                element.text = ""


def _hyperlink_field(instruction: str, transform: TextTransform) -> str:
    """Adresse d'un champ HYPERLINK ; les autres champs ont une syntaxe à conserver."""
    if "HYPERLINK" not in instruction or "\\l" in instruction:
        return instruction
    return re.sub(r'"([^"]*)"', lambda m: f'"{transform_url(m.group(1), transform)}"', instruction)


def _transform_text_part(root: Any, transform: TextTransform) -> None:
    for paragraph in root.iter(f"{_W}p"):
        _transform_paragraph(paragraph, transform)
    for instruction in root.iter(f"{_W}instrText"):
        instruction.text = _hyperlink_field(instruction.text or "", transform)
    for element in root.iter():
        if not isinstance(element.tag, str):
            continue
        for name in _TEXT_ATTRIBUTES.intersection(element.attrib):
            element.set(name, transform(element.get(name)))
        if element.tag == f"{_W}fldSimple" and element.get(f"{_W}instr"):
            element.set(f"{_W}instr", _hyperlink_field(element.get(f"{_W}instr"), transform))


def _transform_property_part(root: Any, transform: TextTransform) -> None:
    for element in root.iter():
        if (
            isinstance(element.tag, str)
            and element.tag.rpartition("}")[2] in _PROPERTY_TAGS
            and element.text
        ):
            element.text = transform(element.text)


def _transform_settings(root: Any, part: Any, transform: TextTransform) -> None:
    """Variables du document (docVars) et chemin du modèle attaché (C:\\Users\\<nom>…)."""
    for variable in root.iter(f"{_W}docVar"):
        if variable.get(f"{_W}val"):
            variable.set(f"{_W}val", transform(variable.get(f"{_W}val")))
    for template in list(root.iter(f"{_W}attachedTemplate")):
        template.getparent().remove(template)
    for key, relationship in list(part.rels.items()):
        if relationship.reltype.endswith(_ATTACHED_TEMPLATE_RELATIONSHIP):
            del part.rels[key]


def _nearest(element: Any, tag: str) -> Any:
    parent = element.getparent()
    while parent is not None and parent.tag != tag:
        parent = parent.getparent()
    return parent


def _drop_images(part: Any) -> int:
    """Remplace les images d'une partie de texte par « [image retirée] » ; renvoie leur nombre.

    Graphiques, SmartArt et zones de texte restent : seuls les dessins qui portent une image
    (pic:pic) et les images VML sont retirés. Les images que plus rien ne cite ne sont pas
    enregistrées dans le document produit.
    """
    from docx.oxml import OxmlElement

    root = part.element
    targets = [_nearest(pic, f"{_W}drawing") for pic in root.iter(_PIC)]
    for imagedata in root.iter(_V_IMAGEDATA):
        pict = _nearest(imagedata, f"{_W}pict")
        if pict is not None and next(pict.iter(_V_TEXTBOX), None) is None:
            targets.append(pict)
    removed = 0
    for element in {id(e): e for e in targets if e is not None}.values():
        if element.getparent() is None:
            continue
        text = OxmlElement("w:t")
        text.text = IMAGE_PLACEHOLDER
        element.getparent().replace(element, text)
        removed += 1
    if removed:
        cited = {value for element in root.iter() for value in element.attrib.values()}
        for key, relationship in list(part.rels.items()):
            if relationship.reltype.endswith(_IMAGE_RELATIONSHIP) and key not in cited:
                del part.rels[key]
    return removed


def _transform_embedded(
    part: Any, index: int, transform: TextTransform, options: Options = DEFAULT_OPTIONS
) -> None:
    """Classeur ou document incorporé : pseudonymisé comme un fichier, renommé « objet1.xlsx »."""
    import tempfile

    from docx.opc.packuri import PackURI

    from invisibility_cloak.formats import xlsx_handler

    name = str(part.partname)
    suffix = name.rsplit(".", 1)[1].lower()
    handler = xlsx_handler.HANDLER if suffix == "xlsx" else HANDLER
    with tempfile.TemporaryDirectory(prefix="cloak-") as folder:
        source = Path(folder) / f"source.{suffix}"
        target = Path(folder) / f"cible.{suffix}"
        source.write_bytes(part.blob)
        handler.transform(source, target, transform, options)
        part._blob = target.read_bytes()
    part.partname = PackURI(f"{name.rsplit('/', 1)[0]}/objet{index}.{suffix}")


def _transform_part(part: Any, transform: TextTransform) -> None:
    from docx.opc.oxml import serialize_part_xml
    from docx.opc.part import XmlPart
    from docx.oxml import parse_xml

    name = str(part.partname)
    # Toute adresse externe autre qu'un lien (modèle, liaison OLE, image liée) peut citer un chemin local
    for relationship in part.rels.values():
        if relationship.is_external and not relationship.reltype.endswith(_HYPERLINK_RELATIONSHIP):
            relationship._target = transform_url(relationship._target, transform)
    if name == _SETTINGS_PART:
        root = part.element if isinstance(part, XmlPart) else parse_xml(part.blob)
        _transform_settings(root, part, transform)
        if not isinstance(part, XmlPart):
            part._blob = serialize_part_xml(root)
        return
    if _DRAWING_PARTS.fullmatch(name):
        is_xml_part = isinstance(part, XmlPart)
        root = part.element if is_xml_part else parse_xml(part.blob)
        labels = [v for cache in root.iter(f"{_C}strCache") for v in cache.iter(f"{_C}v")]
        for element in [*root.iter(f"{_A}t"), *labels]:
            if element.text and element.text.strip():
                element.text = transform(element.text)
        if not is_xml_part:
            part._blob = serialize_part_xml(root)
        return
    is_text = _TEXT_PARTS.fullmatch(name) is not None
    if not is_text and name not in _PROPERTY_PARTS:
        return
    is_xml_part = isinstance(part, XmlPart)
    root = part.element if is_xml_part else parse_xml(part.blob)
    if is_text:
        _transform_text_part(root, transform)
        for relationship in part.rels.values():
            if relationship.is_external and relationship.reltype.endswith(_HYPERLINK_RELATIONSHIP):
                relationship._target = transform_url(relationship._target, transform)
    else:
        _transform_property_part(root, transform)
    if not is_xml_part:
        part._blob = serialize_part_xml(root)


class DocxHandler:
    def transform(
        self,
        source: Path,
        target: Path,
        transform: TextTransform,
        options: Options = DEFAULT_OPTIONS,
    ) -> None:
        import docx  # import local : dépendance chargée seulement si besoin
        from docx.opc.part import XmlPart

        document = docx.Document(str(source))
        package = document.part.package
        embedded = 0
        for part in list(package.iter_parts()):
            if _EMBEDDED_PART.fullmatch(str(part.partname)):
                embedded += 1
                _transform_embedded(part, embedded, transform, options)
                continue
            _transform_part(part, transform)
            # Après la pseudonymisation : la mention « [image retirée] » reste lisible
            if (
                options.drop_images
                and isinstance(part, XmlPart)
                and _TEXT_PARTS.fullmatch(str(part.partname))
            ):
                _drop_images(part)
        # L'aperçu enregistré par Word montre la première page en clair
        for key, relationship in list(package.rels.items()):
            if relationship.reltype.endswith(_THUMBNAIL_RELATIONSHIP):
                del package.rels[key]
        properties = document.core_properties
        for name in _CORE_PROPERTIES:
            value = getattr(properties, name)
            if value:
                setattr(properties, name, transform(value)[:_CORE_PROPERTY_MAX_LENGTH])
        properties.author = ""
        properties.last_modified_by = ""
        document.save(str(target))


HANDLER = DocxHandler()
