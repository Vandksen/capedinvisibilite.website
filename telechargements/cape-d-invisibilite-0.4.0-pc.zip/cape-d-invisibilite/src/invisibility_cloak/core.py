"""Orchestration : fichier d'entrée → moteur → fichier pseudonymisé + table."""

from __future__ import annotations

import re
import tempfile
from pathlib import Path

from invisibility_cloak import engine_adapter
from invisibility_cloak.errors import MappingError, UnsupportedFormatError
from invisibility_cloak.formats import docx_handler, xlsx_handler
from invisibility_cloak.formats.base import DEFAULT_OPTIONS, FormatHandler, Options
from invisibility_cloak.mapping.table import Mapping

HANDLERS: dict[str, FormatHandler] = {
    ".docx": docx_handler.HANDLER,
    ".xlsx": xlsx_handler.HANDLER,
}
# Le FEC est traité en entier par le moteur : colonnes, numéros de compte, nom du fichier
FEC_SUFFIX = ".txt"
# Formats texte acceptés au rétablissement : FEC et réponses d'une IA
RESTORABLE_TEXT_SUFFIXES = {FEC_SUFFIX, ".csv", ".md"}


# Horodatage des noms produits jusqu'à la version 0.2.0 (_AAAA-MM-JJ_HH-MM-SS) : retiré des
# fichiers reçus, pour qu'un fichier de cette version retrouve un nom sans horodatage
_TIMESTAMP_SUFFIX = re.compile(r"_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}$")


def _base_stem(stem: str) -> str:
    """Nom sans son éventuel horodatage d'une version précédente."""
    return _TIMESTAMP_SUFFIX.sub("", stem)


def _named(stem: str, suffix: str) -> str:
    return f"{_base_stem(stem)}{suffix}"


# Marque d'un fichier pseudonymisé, avec la référence de sa table : « rapport.cloak-3f9a1c ».
# Les fichiers de la version 0.2.0 portent une référence de 3 caractères, début de la nouvelle.
CLOAK_MARK = ".cloak"
_CLOAK_SUFFIX = re.compile(r"\.cloak(?:-([0-9a-f]{6}|[0-9a-f]{3}))?$")


def _cloaked_stem(stem: str, mapping: Mapping) -> str:
    return f"{_base_stem(stem)}{CLOAK_MARK}-{mapping.ref}"


def table_name(mapping: Mapping, suffix: str) -> str:
    """Nom de la table : « table-3f9a1c.xlsx » (ou .map)."""
    return f"table-{mapping.ref}{suffix}"


def table_ref(filename: str) -> str | None:
    """Référence de table portée par le nom d'un fichier pseudonymisé, s'il en a une."""
    match = _CLOAK_SUFFIX.search(_base_stem(Path(filename).stem))
    return match.group(1) if match else None


def check_table(filename: str, mapping: Mapping) -> None:
    """Refuse un fichier pseudonymisé avec une autre table que `mapping`."""
    ref = table_ref(filename)
    if ref and not mapping.ref.startswith(ref):
        raise MappingError(
            f"Ce fichier a été pseudonymisé avec la table {ref}, pas avec la table {mapping.ref}."
        )


def handler_for(path: Path) -> FormatHandler:
    try:
        return HANDLERS[path.suffix.lower()]
    except KeyError:
        raise UnsupportedFormatError(f"Format non pris en charge : {path.suffix}") from None


def anonymize_file(
    source: Path, mapping: Mapping | None = None, options: Options = DEFAULT_OPTIONS
) -> tuple[Path, Mapping]:
    """Pseudonymise `source` et renvoie (fichier de sortie, table de correspondance)."""
    mapping = mapping or Mapping()
    if source.suffix.lower() == FEC_SUFFIX:
        name, content = engine_adapter.pseudonymize_fec(source, mapping)
        output = Path(name)
        if output.stem.endswith("-anonyme"):
            # Nom sans SIREN : il est gardé par le moteur, il peut citer le client
            stem = output.stem.removesuffix("-anonyme")
            output = output.with_name(f"{_safe_stem(stem, mapping)}-anonyme{output.suffix}")
        target = source.with_name(_named(_cloaked_stem(output.stem, mapping), output.suffix))
        target.write_bytes(content)
        return target, mapping
    handler = handler_for(source)
    stem = _safe_stem(_CLOAK_SUFFIX.sub("", _base_stem(source.stem)), mapping)
    target = source.with_name(_named(_cloaked_stem(stem, mapping), source.suffix))
    handler.transform(
        source, target, lambda text: engine_adapter.pseudonymize(text, mapping), options
    )
    return target, mapping


def _safe_stem(stem: str, mapping: Mapping) -> str:
    """Nom de fichier pseudonymisé : « Bilan HUMBERT 2024 » → « Bilan 6eaef97 2024 »."""
    return engine_adapter.pseudonymize(stem, mapping)


def anonymize_bytes(
    filename: str,
    content: bytes,
    mapping: Mapping | None = None,
    options: Options = DEFAULT_OPTIONS,
) -> tuple[str, bytes, Mapping]:
    """Pseudonymise un fichier reçu en mémoire ; renvoie (nom de sortie, contenu, table).

    Point d'entrée unique de l'interface web : le type est déduit de l'extension et rien
    ne reste sur le disque (dossier temporaire supprimé, même en cas d'erreur).
    """
    # Seul le nom final compte : le chemin d'origine n'est jamais utilisé
    name = Path(filename).name
    suffix = Path(name).suffix.lower()
    if suffix != FEC_SUFFIX:
        handler_for(Path(name))
    with tempfile.TemporaryDirectory(prefix="cloak-") as folder:
        source = Path(folder) / name
        source.write_bytes(content)
        target, mapping = anonymize_file(source, mapping, options)
        return target.name, target.read_bytes(), mapping


def restore_file(path: Path, mapping: Mapping) -> tuple[Path, bool]:
    """Rétablit un FEC, un texte, un Word ou un Excel ; renvoie (fichier, identique à l'origine)."""
    check_table(path.name, mapping)
    # Un seul index de la table pour le nom et le contenu : il est long à construire
    restore = mapping.restorer()
    base = restore(_CLOAK_SUFFIX.sub("", _base_stem(path.stem)))
    target = path.with_name(_named(f"{base}.restored", path.suffix))
    handler = HANDLERS.get(path.suffix.lower())
    if handler is not None:
        handler.transform(path, target, restore)
        return target, False
    content, exact = mapping.restore_content(path.read_bytes(), restore)
    target.write_bytes(content)
    return target, exact


def restore_bytes(filename: str, content: bytes, mapping: Mapping) -> tuple[str, bytes, bool]:
    """Rétablit un fichier reçu en mémoire ; renvoie (nom de sortie, contenu, identique).

    Un FEC rétabli à l'identique reprend son nom d'origine. Rien ne reste sur le disque.
    """
    name = Path(filename).name
    suffix = Path(name).suffix.lower()
    if suffix not in HANDLERS and suffix not in RESTORABLE_TEXT_SUFFIXES:
        raise UnsupportedFormatError(f"Format non pris en charge : {suffix}")
    original_name = mapping.original_fec_name(content)
    with tempfile.TemporaryDirectory(prefix="cloak-") as folder:
        source = Path(folder) / name
        source.write_bytes(content)
        target, exact = restore_file(source, mapping)
        restored = target.read_bytes()
    if exact and original_name:
        original = Path(original_name)
        return _named(original.stem, original.suffix), restored, True
    return target.name, restored, exact
