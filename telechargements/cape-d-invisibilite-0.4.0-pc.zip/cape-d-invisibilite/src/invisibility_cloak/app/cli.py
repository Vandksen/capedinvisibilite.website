"""Ligne de commande provisoire : `cloak anonymize` et `cloak restore`."""

from __future__ import annotations

import argparse
import getpass
import sys
from pathlib import Path

from invisibility_cloak import __version__
from invisibility_cloak.core import anonymize_file, restore_file, table_name
from invisibility_cloak.errors import CloakError
from invisibility_cloak.formats.base import Options
from invisibility_cloak.mapping.table import Mapping


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="cloak", description="Cape d'invisibilité — 100 % local")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_anon = sub.add_parser("anonymize", help="Pseudonymiser des fichiers Word, Excel ou FEC")
    p_anon.add_argument("files", type=Path, nargs="+")
    p_anon.add_argument("--table", type=Path, help="table existante à compléter (.xlsx ou .map)")
    p_anon.add_argument(
        "--figer-valeurs", action="store_true", help="Excel : formules remplacées par leur résultat"
    )
    p_anon.add_argument("--retirer-images", action="store_true", help="Word : images retirées")

    p_rest = sub.add_parser("restore", help="Réinjecter les vraies valeurs dans un texte ou un FEC")
    p_rest.add_argument("file", type=Path)
    p_rest.add_argument("--map", type=Path, required=True, help="table (.xlsx ou .map)")

    args = parser.parse_args(argv)
    try:
        if args.command == "anonymize":
            password = getpass.getpass("Mot de passe de la table (vide : table en clair .xlsx) : ")
            mapping = _read_table(args.table, password) if args.table else Mapping()
            for source in args.files:
                options = Options(freeze_values=args.figer_valeurs, drop_images=args.retirer_images)
                target, _ = anonymize_file(source, mapping, options)
                print(f"Fichier pseudonymisé : {target}")
            suffix, content = mapping.export(password)
            table_path = args.files[0].with_name(table_name(mapping, suffix))
            table_path.write_bytes(content)
            print(f"Table de correspondance {mapping.ref} : {table_path}")
        else:
            mapping = _read_table(args.map, None)
            out, exact = restore_file(args.file, mapping)
            print(f"Fichier restauré : {out}" + (" (identique à l'original)" if exact else ""))
    except CloakError as error:
        print(f"Erreur : {error}", file=sys.stderr)
        return 1
    return 0


def _read_table(path: Path, password: str | None) -> Mapping:
    """Table en clair, ou chiffrée : le mot de passe n'est demandé que pour celle-ci."""
    raw = path.read_bytes()
    if password is None and not Mapping.is_table(raw):
        password = getpass.getpass("Mot de passe de la table : ")
    return Mapping.read(raw, password or "")


if __name__ == "__main__":
    raise SystemExit(main())
