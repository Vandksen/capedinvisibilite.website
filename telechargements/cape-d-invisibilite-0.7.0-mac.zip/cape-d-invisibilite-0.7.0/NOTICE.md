# Avis sur les données de tiers

Le code de Cape d'invisibilité est distribué sous licence MIT (voir `LICENSE`).

L'application embarque aussi des listes de mots tirées de sources extérieures. Elles sont
livrées comme fichiers de données séparés, dans `engine/references/`, et restent
sous leur propre licence. Aucune ne contient de donnée personnelle ni de donnée client.

## Lexique 3.83

- Fichiers concernés : `francais.txt` et `mots-outils.txt`.
- Source : Lexique 3.83, http://www.lexique.org
- Auteurs : Boris New, Christophe Pallier, Marc Brysbaert et Ludovic Ferrand. Référence :
  New, B., Pallier, C., Brysbaert, M. et Ferrand, L. (2004). Lexique 2 : A new French lexical
  database. *Behavior Research Methods, Instruments, & Computers*, 36(3), 516-524.
- Licence : Creative Commons Attribution - Partage dans les mêmes conditions 4.0 International
  (CC BY-SA 4.0), https://creativecommons.org/licenses/by-sa/4.0/deed.fr
- Modifications : seules les formes écrites sont reprises, réduites en minuscules sans accents
  et dédoublonnées ; `mots-outils.txt` ne garde que les articles, pronoms, prépositions et
  conjonctions, plus quelques titres de civilité.
- Ces deux fichiers sont redistribués sous la même licence CC BY-SA 4.0. Vous pouvez les
  réutiliser et les modifier aux conditions de cette licence, en citant la source.

## INSEE

- Fichiers concernés : `prenoms.txt` et `noms-de-famille.txt`.
- Sources : INSEE, fichier des prénoms (état civil, édition 2022) et fichier des noms de famille
  (naissances de 1891 à 2000), https://www.insee.fr
- Licence : Licence Ouverte 2.0 (Etalab), https://www.etalab.gouv.fr/licence-ouverte-open-licence
- Modifications : seuls les prénoms et les noms les plus fréquents sont repris, réduits en
  minuscules sans accents, sans aucun effectif ; pour les noms, seuls ceux qui sont aussi des
  mots courants.

## Régénérer ces fichiers

`packaging/construire_dictionnaire.py` les reconstruit hors ligne à partir des fichiers sources.
L'application ne télécharge rien.
