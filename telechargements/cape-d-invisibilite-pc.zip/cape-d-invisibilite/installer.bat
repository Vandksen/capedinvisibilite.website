@echo off
rem Installation, une seule fois, de Cape d'invisibilite sur PC. Equivalent Mac : installer.command
rem Necessite Python 3.11 ou plus recent : https://www.python.org/downloads/
chcp 65001 >nul
cd /d "%~dp0"

py -3 -c "import sys; sys.exit(sys.version_info < (3, 11))" >nul 2>&1
if errorlevel 1 (
    echo Python 3.11 ou plus recent est introuvable. Installez-le, puis relancez ce fichier.
    pause
    exit /b 1
)

py -3 -m venv .venv
if errorlevel 1 (
    echo La creation de l'environnement a echoue.
    pause
    exit /b 1
)

.venv\Scripts\python -m pip install -r requirements.txt
if errorlevel 1 (
    echo L'installation a echoue.
    pause
    exit /b 1
)

echo.
echo Installation terminee. Lancez "Lancer Cape d'invisibilite.bat".
pause
