@echo off
rem Demarre la page web locale et ouvre le navigateur. Equivalent Mac : Lancer Cape d'invisibilite.command
rem Fermer cette fenetre arrete l'application.
chcp 65001 >nul
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Cape d'invisibilite n'est pas installe. Lancez d'abord installer.bat.
    pause
    exit /b 1
)

.venv\Scripts\python -m invisibility_cloak.app.web
if errorlevel 1 pause
