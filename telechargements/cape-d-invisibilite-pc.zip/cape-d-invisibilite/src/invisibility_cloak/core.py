"""Orchestration : fichier d'entrée → moteur → fichier pseudonymisé + table."""

from __future__ import annotations

import tempfile
from pathlib import Path

from invisibility_cloak import engine_adapter
from invisibility_cloak.errors import UnsupportedFormatError
from invisibility_cloak.formats import docx_handler, xlsx_handler
from invisibility_cloak.formats.base import FormatHandler
from invisibility_cloak.mapping.table import Mapping

HANDLERS: dict[str, FormatHandler] = {
    ".docx": docx_handler.HANDLER,
    ".xlsx": xlsx_handler.HANDLER,
}
# Le FEC est traité en entier par le moteur : colonnes, numéros de compte, nom du fichier
FEC_SUFFIX = ".txt"
# Formats texte acceptés au rétablissement : FEC et réponses d'une IA
RESTORABLE_TEXT_SUFFIXES = {FEC_SUFFIX, ".csv", ".md"}


def handler_for(path: Path) -> FormatHandler:
    try:
        return HANDLERS[path.suffix.lower()]
    except KeyError:
        raise UnsupportedFormatError(f"Format non pris en charge : {path.suffix}") from None


def anonymize_file(source: Path, mapping: Mapping | None = None) -> tuple[Path, Mapping]:
    """Pseudonymise `source` et renvoie (fichier de sortie, table de correspondance)."""
    mapping = mapping or Mapping()
    if source.suffix.lower() == FEC_SUFFIX:
        name, content = engine_adapter.pseudonymize_fec(source, mapping)
        target = source.with_name(name)
        target.write_bytes(content)
        return target, mapping
    handler = handler_for(source)
    target = source.with_name(f"{source.stem}.cloak{source.suffix}")
    handler.transform(source, target, lambda text: engine_adapter.pseudonymize(text, mapping))
    return target, mapping


def anonymize_bytes(
    filename: str, content: bytes, mapping: Mapping | None = None
) -> tuple[str, bytes, Mapping]:
    """Pseudonymise un fichier reçu en mémoire ; renvoie (nom de sortie, contenu, table).

    Point d'entrée unique de l'interface web : le type est déduit de l'extension et rien
    ne reste sur le disque (dossier temporaire supprimé, même en cas d'erreur).
    """
    # Seul le nom final compte : le chemin d'origine n'est jamais utilisé
    name = Path(filename).name
    suffix = Path(name).suffix.lower()
    if suffix != FEC_SUFFIX:
        handler_for(Path(name))
    with tempfile.TemporaryDirectory(prefix="cloak-") as folder:
        source = Path(folder) / name
        source.write_bytes(content)
        target, mapping = anonymize_file(source, mapping)
        return target.name, target.read_bytes(), mapping


def restore_file(path: Path, mapping: Mapping) -> tuple[Path, bool]:
    """Rétablit un FEC, un texte, un Word ou un Excel ; renvoie (fichier, identique à l'origine)."""
    target = path.with_name(f"{path.stem}.restored{path.suffix}")
    handler = HANDLERS.get(path.suffix.lower())
    if handler is not None:
        handler.transform(path, target, mapping.restorer())
        return target, False
    content, exact = engine_adapter.restore_content(path.read_bytes(), mapping.to_table())
    target.write_bytes(content)
    return target, exact


def restore_bytes(filename: str, content: bytes, mapping: Mapping) -> tuple[str, bytes, bool]:
    """Rétablit un fichier reçu en mémoire ; renvoie (nom de sortie, contenu, identique).

    Un FEC rétabli à l'identique reprend son nom d'origine. Rien ne reste sur le disque.
    """
    name = Path(filename).name
    suffix = Path(name).suffix.lower()
    if suffix not in HANDLERS and suffix not in RESTORABLE_TEXT_SUFFIXES:
        raise UnsupportedFormatError(f"Format non pris en charge : {suffix}")
    with tempfile.TemporaryDirectory(prefix="cloak-") as folder:
        source = Path(folder) / name
        source.write_bytes(content)
        target, exact = restore_file(source, mapping)
        restored = target.read_bytes()
    if exact and mapping.file:
        return mapping.file[0], restored, True
    return target.name.replace(".cloak.restored", ".restored"), restored, exact
