"""Table de correspondance valeur d'origine ↔ pseudonyme.

Son contenu est celui de la table du moteur : formes exactes des mots et des numéros, avec
leurs occurrences, et pour un FEC le nom, l'empreinte, le SIREN et les champs enregistrés en
entier. Seule l'enveloppe diffère : ici, la table est chiffrée sur disque (Fernet), la clé est
dérivée d'un mot de passe.
"""

from __future__ import annotations

import base64
import json
import os
import secrets
from collections import Counter
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from invisibility_cloak import engine_adapter
from invisibility_cloak.errors import MappingError


@dataclass
class Mapping:
    # Clé du moteur : avec la même table, une même valeur garde le même pseudonyme
    # d'un fichier à l'autre. Sauvegardée chiffrée avec la table.
    secret: str = field(default_factory=lambda: secrets.token_hex(32), repr=False)
    words: Counter[tuple[str, str]] = field(default_factory=Counter, repr=False)
    numbers: Counter[tuple[str, str]] = field(default_factory=Counter, repr=False)
    # Propres à un FEC : une table en couvre un seul
    file: tuple[str, str] | None = field(default=None, repr=False)
    fingerprint: tuple[str, str] | None = field(default=None, repr=False)
    siren: tuple[str, str] | None = field(default=None, repr=False)
    fields: dict[str, tuple[str, str]] = field(default_factory=dict, repr=False)

    def known_values(self) -> list[str]:
        return [original for original, _ in (*self.words, *self.numbers)]

    def to_table(self) -> dict[str, Any]:
        """Table au format du moteur."""
        return {
            "fichier": self.file,
            "empreinte": self.fingerprint,
            "siren": self.siren,
            "mots": [(o, p, n) for (o, p), n in sorted(self.words.items())],
            "nombres": [(o, p, n) for (o, p), n in sorted(self.numbers.items())],
            "champs": self.fields,
        }

    def absorb(self, table: dict[str, Any]) -> None:
        """Ajoute le contenu d'une table du moteur."""
        if table["fichier"]:
            if self.file:
                raise MappingError("Une table ne couvre qu'un seul FEC.")
            self.file, self.fingerprint = table["fichier"], table["empreinte"]
            self.siren, self.fields = table["siren"], table["champs"]
        for original, pseudonym, count in table["mots"]:
            self.words[(original, pseudonym)] += count
        for original, pseudonym, count in table["nombres"]:
            self.numbers[(original, pseudonym)] += count

    def restore(self, text: str) -> str:
        return engine_adapter.restore_text(text, self.to_table())

    def restorer(self) -> Callable[[str], str]:
        """Rétablissement à réutiliser pour tous les fragments d'un fichier (Word, Excel)."""
        return engine_adapter.text_restorer(self.to_table())

    # --- persistance chiffrée -------------------------------------------------

    def save(self, path: Path, password: str) -> None:
        path.write_bytes(self.to_bytes(password))

    def to_bytes(self, password: str) -> bytes:
        """Table chiffrée, telle qu'écrite par `save` (lisible par `load`)."""
        from cryptography.fernet import Fernet

        salt = os.urandom(16)
        payload = {"table": engine_adapter.table_to_text(self.to_table()), "secret": self.secret}
        token = Fernet(_derive_key(password, salt)).encrypt(json.dumps(payload).encode())
        return salt + token

    @classmethod
    def load(cls, path: Path, password: str) -> Mapping:
        return cls.from_bytes(path.read_bytes(), password)

    @classmethod
    def from_bytes(cls, raw: bytes, password: str) -> Mapping:
        """Relit une table chiffrée par `to_bytes` ou `save`."""
        from cryptography.fernet import Fernet, InvalidToken

        salt, token = raw[:16], raw[16:]
        try:
            data = json.loads(Fernet(_derive_key(password, salt)).decrypt(token))
        except InvalidToken:
            raise MappingError("Mot de passe incorrect ou table corrompue") from None
        mapping = cls(secret=data["secret"])
        mapping.absorb(engine_adapter.text_to_table(data["table"]))
        return mapping


def _derive_key(password: str, salt: bytes) -> bytes:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=600_000)
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))
