"""Ligne de commande provisoire : `cloak anonymize` et `cloak restore`."""

from __future__ import annotations

import argparse
import getpass
import sys
from pathlib import Path

from invisibility_cloak.core import anonymize_file, restore_file
from invisibility_cloak.errors import CloakError
from invisibility_cloak.mapping.table import Mapping


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="cloak", description="Cape d'invisibilité — 100 % local")
    sub = parser.add_subparsers(dest="command", required=True)

    p_anon = sub.add_parser("anonymize", help="Pseudonymiser un fichier Word, Excel ou FEC")
    p_anon.add_argument("file", type=Path)

    p_rest = sub.add_parser("restore", help="Réinjecter les vraies valeurs dans un texte ou un FEC")
    p_rest.add_argument("file", type=Path)
    p_rest.add_argument("--map", type=Path, required=True)

    args = parser.parse_args(argv)
    try:
        if args.command == "anonymize":
            target, mapping = anonymize_file(args.file)
            map_path = target.with_suffix(".map")
            mapping.save(map_path, getpass.getpass("Mot de passe de la table : "))
            print(f"Fichier pseudonymisé : {target}\nTable de correspondance : {map_path}")
        else:
            mapping = Mapping.load(args.map, getpass.getpass("Mot de passe de la table : "))
            out, exact = restore_file(args.file, mapping)
            print(f"Fichier restauré : {out}" + (" (identique à l'original)" if exact else ""))
    except CloakError as error:
        print(f"Erreur : {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
