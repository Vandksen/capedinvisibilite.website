"""Interface web locale : une page servie par Flask, sur ce poste uniquement.

L'utilisateur dépose un fichier (Word, Excel, FEC) dans la page et choisit un mot de passe ;
le navigateur télécharge une archive ZIP qui contient le fichier pseudonymisé et sa table de
correspondance chiffrée par ce mot de passe (`.map`). La seconde partie de la page rétablit
les vraies valeurs à partir d'un fichier, de sa table et du mot de passe. Rien n'est conservé
sur le disque et le serveur n'écoute que sur 127.0.0.1 : il est inaccessible depuis le réseau.

Lancement : `Lancer Cape d'invisibilite` (.bat sur PC, .command sur Mac).
"""

from __future__ import annotations

import argparse
import io
import threading
import webbrowser
import zipfile
from pathlib import PurePath

from flask import Flask, Response, abort, jsonify, render_template, request, send_file

from invisibility_cloak.core import anonymize_bytes, restore_bytes
from invisibility_cloak.errors import CloakError
from invisibility_cloak.mapping.table import Mapping

HOST = "127.0.0.1"
# Même port sur Mac et sur PC ; sur Mac, le port 5000 est souvent pris par AirPlay
DEFAULT_PORT = 5055
# Un FEC de grosse société dépasse vite 100 Mo
MAX_UPLOAD_BYTES = 500 * 1024 * 1024
# Noms d'hôte acceptés : bloque une page web distante qui viserait ce serveur
# par rebinding DNS (son nom d'hôte ne serait pas l'un de ceux-ci)
LOCAL_HOSTS = {"127.0.0.1", "localhost"}
MAP_SUFFIX = ".map"


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_BYTES

    @app.before_request
    def local_only() -> None:
        if request.host.rsplit(":", 1)[0] not in LOCAL_HOSTS:
            abort(403)

    @app.get("/")
    def index() -> str:
        return render_template("index.html")

    @app.post("/anonymiser")
    def anonymiser() -> Response | tuple[Response, int]:
        upload = request.files.get("fichier")
        if upload is None or not upload.filename:
            return _error("Aucun fichier reçu.", 400)
        password = request.form.get("mot_de_passe", "")
        if not password:
            return _error("Choisissez un mot de passe pour la table de correspondance.", 400)
        try:
            name, content, mapping = anonymize_bytes(upload.filename, upload.read())
            table = mapping.to_bytes(password)
        except CloakError as error:
            return _error(str(error), 400)
        except Exception:  # noqa: BLE001 — toute erreur, sans en divulguer le détail
            # Message générique : le détail pourrait contenir une valeur du fichier
            return _error("Le fichier n'a pas pu être traité.", 500)
        stem = PurePath(name).stem
        return send_file(
            io.BytesIO(_bundle(name, content, f"{stem}{MAP_SUFFIX}", table)),
            as_attachment=True,
            download_name=f"{stem}.zip",
            mimetype="application/zip",
        )

    @app.post("/desanonymiser")
    def desanonymiser() -> Response | tuple[Response, int]:
        upload = request.files.get("fichier")
        table = request.files.get("table")
        if upload is None or not upload.filename:
            return _error("Aucun fichier à rétablir reçu.", 400)
        if table is None or not table.filename:
            return _error("Ajoutez la table de correspondance (.map).", 400)
        password = request.form.get("mot_de_passe", "")
        if not password:
            return _error("Saisissez le mot de passe de la table de correspondance.", 400)
        try:
            mapping = Mapping.from_bytes(table.read(), password)
            name, content, exact = restore_bytes(upload.filename, upload.read(), mapping)
        except CloakError as error:
            return _error(str(error), 400)
        except Exception:  # noqa: BLE001 — toute erreur, sans en divulguer le détail
            return _error("Le fichier n'a pas pu être rétabli.", 500)
        response = send_file(
            io.BytesIO(content),
            as_attachment=True,
            download_name=name,
            mimetype="application/octet-stream",
        )
        response.headers["X-Cloak-Identique"] = "1" if exact else "0"
        return response

    @app.errorhandler(413)
    def too_large(_exception: Exception) -> tuple[Response, int]:
        return _error(f"Fichier trop volumineux (maximum {MAX_UPLOAD_BYTES // 1024**2} Mo).", 413)

    return app


def _bundle(name: str, content: bytes, map_name: str, table: bytes) -> bytes:
    """Archive ZIP du fichier pseudonymisé et de sa table chiffrée, construite en mémoire."""
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(name, content)
        archive.writestr(map_name, table)
    return buffer.getvalue()


def _error(message: str, status: int) -> tuple[Response, int]:
    return jsonify(erreur=message), status


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Cape d'invisibilité — page web locale")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--no-browser", action="store_true", help="Ne pas ouvrir le navigateur")
    args = parser.parse_args(argv)

    url = f"http://{HOST}:{args.port}/"
    if not args.no_browser:
        threading.Timer(1.0, webbrowser.open, args=(url,)).start()
    print(f"Cape d'invisibilité est ouvert sur {url} — fermez cette fenêtre pour l'arrêter.")
    create_app().run(host=HOST, port=args.port, debug=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
