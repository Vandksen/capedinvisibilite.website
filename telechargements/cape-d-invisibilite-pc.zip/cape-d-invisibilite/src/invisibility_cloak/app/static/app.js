// Envoie les fichiers au serveur local et déclenche le téléchargement du résultat.
(() => {
  const el = (id) => document.getElementById(id);

  function afficher(statut, message, type) {
    statut.textContent = message;
    statut.className = "statut" + (type ? " " + type : "");
  }

  // Nom proposé par le serveur (en-tête Content-Disposition, UTF-8 si présent)
  function nomDuFichier(entete, secours) {
    if (!entete) return secours;
    const utf8 = /filename\*=UTF-8''([^;]+)/i.exec(entete);
    if (utf8) return decodeURIComponent(utf8[1]);
    const simple = /filename="?([^";]+)"?/i.exec(entete);
    return simple ? simple[1] : secours;
  }

  // Envoie le formulaire, télécharge la réponse ; renvoie { nom, reponse }
  async function envoyerEtTelecharger(url, donnees, secours) {
    const reponse = await fetch(url, { method: "POST", body: donnees });
    if (!reponse.ok) {
      const corps = await reponse.json().catch(() => ({}));
      throw new Error(corps.erreur || "Le fichier n'a pas pu être traité.");
    }
    const contenu = await reponse.blob();
    const nom = nomDuFichier(reponse.headers.get("Content-Disposition"), secours);
    const lien = document.createElement("a");
    lien.href = URL.createObjectURL(contenu);
    lien.download = nom;
    document.body.appendChild(lien);
    lien.click();
    lien.remove();
    setTimeout(() => URL.revokeObjectURL(lien.href), 1000);
    return { nom, reponse };
  }

  // Glisser-déposer sur une zone ; `surFichier` reçoit le fichier choisi ou déposé
  function brancherZone(zone, champ, surFichier) {
    champ.addEventListener("change", () => surFichier(champ.files[0]));
    ["dragenter", "dragover"].forEach((evt) =>
      zone.addEventListener(evt, (e) => { e.preventDefault(); zone.classList.add("survol"); }));
    ["dragleave", "drop"].forEach((evt) =>
      zone.addEventListener(evt, (e) => { e.preventDefault(); zone.classList.remove("survol"); }));
    zone.addEventListener("drop", (e) => {
      if (e.dataTransfer.files.length) {
        champ.files = e.dataTransfer.files;
        surFichier(champ.files[0]);
      }
    });
  }

  // --- Pseudonymiser ---------------------------------------------------------------
  const formulaire = el("formulaire");
  const zone = el("zone");
  const champ = el("fichier");
  const statut = el("statut");
  const motDePasse = el("mot_de_passe");

  async function pseudonymiser(fichier) {
    if (!fichier) return;
    if (!motDePasse.value) {
      champ.value = "";
      afficher(statut, "Choisissez d'abord un mot de passe pour la table de correspondance.", "erreur");
      motDePasse.focus();
      return;
    }
    const donnees = new FormData();
    donnees.append("fichier", fichier);
    donnees.append("mot_de_passe", motDePasse.value);
    zone.classList.add("occupee");
    afficher(statut, "Pseudonymisation en cours…");
    try {
      const { nom } = await envoyerEtTelecharger(formulaire.action, donnees, "resultat.zip");
      afficher(statut, "Téléchargé : " + nom + " (fichier pseudonymisé + table de correspondance)", "succes");
    } catch (erreur) {
      afficher(statut, erreur.message, "erreur");
    } finally {
      zone.classList.remove("occupee");
      champ.value = "";
    }
  }

  brancherZone(zone, champ, pseudonymiser);
  formulaire.addEventListener("submit", (e) => e.preventDefault());

  // --- Rétablir --------------------------------------------------------------------
  const retablir = el("retablir");
  const fichierRetablir = el("fichier-retablir");
  const table = el("table");
  const motDePasseRetablir = el("mot_de_passe_retablir");
  const bouton = el("bouton-retablir");
  const statutRetablir = el("statut-retablir");

  function montrerNom(zoneCible, fichier) {
    const aide = zoneCible.querySelector(".zone-aide");
    aide.textContent = fichier ? fichier.name : aide.dataset.defaut;
    zoneCible.classList.toggle("choisie", Boolean(fichier));
  }

  brancherZone(el("zone-retablir"), fichierRetablir, (f) => montrerNom(el("zone-retablir"), f));
  brancherZone(el("zone-table"), table, (f) => montrerNom(el("zone-table"), f));

  retablir.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fichier = fichierRetablir.files[0];
    if (!fichier) return afficher(statutRetablir, "Ajoutez le fichier à rétablir.", "erreur");
    if (!table.files[0]) return afficher(statutRetablir, "Ajoutez la table de correspondance (.map).", "erreur");
    if (!motDePasseRetablir.value) {
      motDePasseRetablir.focus();
      return afficher(statutRetablir, "Saisissez le mot de passe de la table.", "erreur");
    }
    bouton.disabled = true;
    afficher(statutRetablir, "Rétablissement en cours…");
    try {
      const { nom, reponse } = await envoyerEtTelecharger(retablir.action, new FormData(retablir), fichier.name);
      const identique = reponse.headers.get("X-Cloak-Identique") === "1";
      afficher(statutRetablir, "Téléchargé : " + nom + (identique ? " (identique à l'original)" : ""), "succes");
    } catch (erreur) {
      afficher(statutRetablir, erreur.message, "erreur");
    } finally {
      bouton.disabled = false;
    }
  });

  // Un fichier lâché à côté d'une zone ne doit pas être ouvert par le navigateur
  window.addEventListener("dragover", (e) => e.preventDefault());
  window.addEventListener("drop", (e) => e.preventDefault());
})();
