"""Cape d'invisibilité — pseudonymisation locale de fichiers avant usage de l'IA."""

__version__ = "0.1.0"
