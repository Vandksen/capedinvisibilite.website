"""Unique point de contact avec le moteur existant (dossier engine/).

Le moteur (`engine/scripts/invisibility_cloak.py`) est chargé par son chemin, sans
modification : son module porte le même nom que ce paquet, il ne peut donc pas être
importé normalement.

Traduction entre les deux interfaces :

- le moteur remplace chaque mot hors du lexique comptable (`engine/references/`) par un
  code hexadécimal de 7 caractères, comme un identifiant court de commit Git (« 3f9a1c2 »),
  et chaque numéro de 5 chiffres ou plus, téléphone
  ou IBAN par des chiffres fictifs ;
- un FEC est traité en entier par le moteur, en mémoire ; les autres formats lui passent
  leur texte fragment par fragment ;
- la table de la `Mapping` a le contenu de celle du moteur, qui sait aussi la relire et
  lever l'anonymat ;
- la clé du moteur est `Mapping.secret` : avec la même table, une même valeur reçoit le
  même pseudonyme d'un fichier à l'autre ;
- une table peut couvrir plusieurs FEC : chacun garde sa table du moteur complète, et deux
  SIREN différents reçoivent deux SIREN fictifs différents.
"""

from __future__ import annotations

import functools
import hashlib
import importlib.util
import re
import weakref
from collections.abc import Callable
from pathlib import Path
from types import ModuleType
from typing import TYPE_CHECKING, Any

from invisibility_cloak.errors import CloakError, EngineNotAvailableError

if TYPE_CHECKING:
    from invisibility_cloak.mapping.table import Mapping

# Paquet installé : le moteur est livré dans invisibility_cloak/engine. Dépôt ou installation
# éditable : il est à la racine du projet, à côté de src/.
_PACKAGED_ENGINE = Path(__file__).resolve().parent / "engine"
ENGINE_DIR = (
    _PACKAGED_ENGINE
    if (_PACKAGED_ENGINE / "scripts").is_dir()
    else Path(__file__).resolve().parents[2] / "engine"
)
ENGINE_SCRIPT = ENGINE_DIR / "scripts" / "invisibility_cloak.py"

# Un état du moteur par table de correspondance (supprimé avec la table)
_CAPES: dict[int, Any] = {}


@functools.cache
def _engine() -> ModuleType:
    if not ENGINE_SCRIPT.is_file():
        raise EngineNotAvailableError("Moteur introuvable dans engine/scripts/.")
    spec = importlib.util.spec_from_file_location("_cloak_engine", ENGINE_SCRIPT)
    if spec is None or spec.loader is None:
        raise EngineNotAvailableError("Moteur illisible dans engine/scripts/.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@functools.cache
def _lexicon() -> frozenset[str]:
    engine = _engine()
    return frozenset(engine.lire_lexique(engine.LEXIQUE_PCG, engine.MOTS_CONSERVES))


def _cape(mapping: Mapping) -> Any:
    key = id(mapping)
    if key not in _CAPES:
        engine = _engine()
        cape = engine.Cape(bytes.fromhex(mapping.secret), set(_lexicon()), "", "", "")
        # Les pseudonymes évitent les valeurs déjà connues de la table
        for value in mapping.known_values():
            cape.pris.update(engine.normaliser(m) for m in engine._MOT.findall(value))
            cape.chiffres_pris.update(re.findall(r"\d{5,}", value))
        # … et reprennent ceux déjà attribués (table relue, FEC traité avant) : sans cela, deux
        # valeurs différentes de deux fichiers peuvent recevoir le même pseudonyme
        known = _known(mapping)
        cape.amorcer(known["mots"], known["nombres"])
        # Chaque remplacement est enregistré dans la table au fil de l'eau
        cape.formes_mots = mapping.words
        cape.formes_nombres = mapping.numbers
        _CAPES[key] = cape
        weakref.finalize(mapping, _CAPES.pop, key, None)
    return _CAPES[key]


def _known(mapping: Mapping) -> dict[str, dict[str, str]]:
    """Pseudonymes déjà attribués par la table, au format de l'état du moteur."""
    engine = _engine()
    words = {engine.normaliser(o): p for (o, p) in mapping.words}
    numbers: dict[str, str] = {}
    for original, fictive in mapping.numbers:
        digits, fictive_digits = re.sub(r"\D", "", original), re.sub(r"\D", "", fictive)
        if digits and len(digits) == len(fictive_digits):
            numbers[digits] = fictive_digits
    return {"mots": words, "nombres": numbers}


def pseudonymize(text: str, mapping: Mapping) -> str:
    """Remplace les valeurs sensibles de `text` par des pseudonymes.

    Chaque remplacement est enregistré dans `mapping`, pour qu'une même valeur reçoive
    toujours le même pseudonyme dans tout le fichier et puisse être restaurée.
    """
    engine = _engine()
    cape = _cape(mapping)
    # Un pseudonyme ne doit jamais être un mot ou un numéro du texte d'origine
    cape.pris.update(engine.normaliser(m) for m in engine._MOT.findall(text))
    cape.chiffres_pris.update(re.findall(r"\d{5,}", text))
    return str(cape.texte(text))


def pseudonymize_fec(source: Path, mapping: Mapping) -> tuple[str, bytes]:
    """Nom et contenu du FEC pseudonymisé ; la table est reçue par `mapping`, rien n'est écrit."""
    engine = _engine()
    key = bytes.fromhex(mapping.secret)
    try:
        result = engine.pseudonymiser_fec(
            source, key, _fictive_siren(source.name, mapping, key), connus=_known(mapping)
        )
    except engine.ErreurFec as error:
        raise CloakError(f"FEC inexploitable : {error}") from None
    mapping.absorb(result["table"])
    # Un Word ou un Excel traité ensuite avec la même table doit connaître les codes de ce FEC
    if id(mapping) in _CAPES:
        known = _known(mapping)
        _CAPES[id(mapping)].amorcer(known["mots"], known["nombres"])
    return str(result["nom"]), bytes(result["octets"])


def _fictive_siren(name: str, mapping: Mapping, key: bytes) -> str:
    """SIREN fictif imposé au moteur quand la table couvre déjà un autre FEC.

    Le moteur tire le SIREN fictif de la seule clé : deux sociétés d'une même table auraient le
    même. Un SIREN déjà vu garde le sien (deux exercices d'une même société) ; un nouveau en
    reçoit un autre, tiré de la clé et du SIREN. Vide : choix du moteur (premier FEC).
    """
    known = mapping.sirens()
    match = re.search(r"(\d{9})FEC\d{8}", name, re.IGNORECASE)
    if not known or not match:
        return ""
    siren = match.group(1)
    if siren in known:
        return known[siren]
    seed = key + siren.encode()
    while True:
        seed = hashlib.sha256(seed).digest()
        fictive = str(_engine().siren_fictif(seed))
        if fictive not in known.values():
            return fictive


def masked_siren(siren: str) -> str:
    """SIREN masqué du nom d'un FEC pseudonymisé (« 97_____65 »)."""
    return str(_engine().siren_masque(siren))


def is_pseudonymized_fec(content: bytes, table: dict[str, Any]) -> bool:
    """`content` est-il le FEC pseudonymisé de `table` (même empreinte) ?"""
    return bool(table.get("empreinte")) and _engine().empreinte(content) == table["empreinte"][1]


def restore_content_as_text(content: bytes, restore: Callable[[str], str]) -> tuple[bytes, bool]:
    """Contenu texte (réponse de l'IA, FEC modifié) rétabli par `restore`, encodage conservé."""
    text, encoding, bom = _engine().decoder(content)
    return (("\ufeff" if bom else "") + restore(text)).encode(encoding), False


def restore_content(content: bytes, table: dict[str, Any]) -> tuple[bytes, bool]:
    """Contenu rétabli, et s'il est garanti identique à l'origine.

    Le FEC pseudonymisé de la table est rétabli champ par champ, vérifié par son empreinte.
    Tout autre contenu (réponse de l'IA, FEC modifié) est traité comme un texte.
    """
    engine = _engine()
    if is_pseudonymized_fec(content, table):
        restored = engine.retablir_fec(content, table)
        if engine.empreinte(restored) != table["empreinte"][0]:
            raise CloakError("Le fichier rétabli diffère de l'original (empreinte).")
        return bytes(restored), True
    return restore_content_as_text(content, text_restorer(table))


def text_restorer(table: dict[str, Any]) -> Callable[[str], str]:
    """Fonction qui rétablit un texte d'après `table`.

    L'index de la table est construit une seule fois : à réutiliser pour tous les fragments
    d'un même fichier, sinon le temps de calcul explose avec la taille de la table.
    """
    restoration = _engine().Restauration(table)

    def restore(text: str) -> str:
        return str(restoration.texte(text))

    return restore


def restore_text(text: str, table: dict[str, Any]) -> str:
    return text_restorer(table)(text)


def table_to_text(table: dict[str, Any]) -> str:
    return str(_engine().table_en_texte(table))


def text_to_table(text: str) -> dict[str, Any]:
    table: dict[str, Any] = _engine().texte_en_table(text)
    return table
